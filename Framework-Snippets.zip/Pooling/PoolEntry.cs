﻿using System;
using UnityEngine;

namespace CardboardCore.Pooling
{
    [Serializable]
    public struct PoolEntry
    {
        [SerializeField] private MonoBehaviour prefab;
        [SerializeField] private int initialAmount;

        public MonoBehaviour Prefab => prefab;
        public int InitialAmount => initialAmount;
    }
}
