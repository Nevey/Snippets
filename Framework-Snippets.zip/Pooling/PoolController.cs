﻿using System;
using System.Collections.Generic;
using CardboardCore.DI;
using UnityEngine;
using Object = UnityEngine.Object;

namespace CardboardCore.Pooling
{
    [Injectable(Singleton = true)]
    public class PoolController
    {
        private readonly Dictionary<PoolConfig, Pool> pools = new Dictionary<PoolConfig, Pool>();

        public T Pop<T>(PoolConfig poolConfig, string instanceName, Transform parent = null) where T : MonoBehaviour
        {
            if (instanceName.EndsWith("(Clone)"))
            {
                instanceName = instanceName.Remove(instanceName.Length - 7, 7);
            }

            if (pools.TryGetValue(poolConfig, out Pool pool))
            {
                return pool.Pop<T>(instanceName, parent);
            }

            pools[poolConfig] = new Pool(poolConfig);

            Log.Write($"New Pool created for Config {poolConfig.name}");

            return pools[poolConfig].Pop<T>(instanceName, parent);
        }

        public bool Push<T>(PoolConfig poolConfig, T instance, bool mayCreateNewPool = false) where T : MonoBehaviour
        {
            if (pools.TryGetValue(poolConfig, out Pool pool))
            {
                pool.Push(instance);
                return true;
            }

            // TODO: Check why this isn't done before trying to get the pool
            if (instance == null)
            {
                return false;
            }

            Log.Warn($"Instance {instance.name} could not be pushed back to it's pool!");

            if (mayCreateNewPool)
            {
                Log.Warn($"New pool created for Instance {instance.name}!");

                pools[poolConfig] = new Pool(poolConfig, true);
                pools[poolConfig].Push(instance);
            }

            return false;
        }
    }

    public class Pool
    {
        private readonly PoolConfig poolConfig;

        private readonly Dictionary<string, Stack<MonoBehaviour>> instances = new Dictionary<string, Stack<MonoBehaviour>>();

        public Pool(PoolConfig poolConfig, bool tryPopulate = false)
        {
            this.poolConfig = poolConfig;

            if (tryPopulate)
            {
                TryPopulate();
            }
        }

        private void TryPopulate()
        {
            if (poolConfig.PoolEntries.Length > 0 && instances.Count == 0)
            {
                Populate();
            }
        }

        private void Populate()
        {
            for (int i = 0; i < poolConfig.PoolEntries.Length; i++)
            {
                PoolEntry poolEntry = poolConfig.PoolEntries[i];

                for (int k = 0; k < poolEntry.InitialAmount; k++)
                {
                    MonoBehaviour instance = Object.Instantiate(poolEntry.Prefab);
                    instance.name = poolEntry.Prefab.name;
                    Push(instance, false);
                }
            }
        }

        public T Pop<T>(string instanceName, Transform parent = null) where T : MonoBehaviour
        {
            TryPopulate();

            string cloneInstanceName = instanceName;

            if (!instances.ContainsKey(cloneInstanceName))
            {
                throw new Exception($"No PoolEntry found for <b>{instanceName}</b>");
            }

            Stack<MonoBehaviour> stack = instances[cloneInstanceName];
            MonoBehaviour instance = stack.Pop();
            T typedInstance = instance as T;

            if (typedInstance == null)
            {
                typedInstance = instance.gameObject.GetComponent<T>();

                if (typedInstance == null)
                {
                    typedInstance = instance.gameObject.GetComponentInChildren<T>();

                    if (typedInstance == null)
                    {
                        throw new Exception($"No Instance found for <b>{instanceName}</b> of type <b>{typeof(T)}</b>");
                    }
                }

                Log.Warn("Found pooled instance via GetComponent, to improve performance, try to assign a prefab to the PoolConfig with the type you want.");
            }

            if (stack.Count == 0)
            {
                MonoBehaviour newInstance = Object.Instantiate(instance);
                newInstance.name = instanceName;
                Push(newInstance, false);
            }

            if (instance.transform is RectTransform rectTransform)
            {
                rectTransform.SetParent(parent, false);
            }
            else
            {
                instance.transform.parent = parent;
            }

            instance.gameObject.SetActive(true);

            if (instance is IPoolable poolable)
            {
                poolable.OnPop();
            }

            return typedInstance;
        }

        public void Push<T>(T instance, bool callInterfaceMethod = true) where T : MonoBehaviour
        {
            if (instance == null)
            {
                return;
            }

            if (!instances.ContainsKey(instance.name))
            {
                instances[instance.name] = new Stack<MonoBehaviour>();
            }

            Stack<MonoBehaviour> stack = instances[instance.name];

            if (callInterfaceMethod && instance is IPoolable poolable)
            {
                poolable.OnPush();
            }

            instance.gameObject.SetActive(false);

            if (instance.transform is RectTransform rectTransform)
            {
                rectTransform.SetParent(null, false);
            }
            else
            {
                instance.transform.parent = null;
            }

            stack.Push(instance);
        }
    }
}
