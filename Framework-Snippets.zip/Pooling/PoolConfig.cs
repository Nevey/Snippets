﻿using UnityEditor;
using UnityEngine;

namespace CardboardCore.Pooling
{
    [CreateAssetMenu(fileName = "PoolConfig", menuName = "Pooling/PoolConfig")]
    public class PoolConfig : ScriptableObject
    {
        [Header("Pool Entries")]
        [SerializeField] private PoolEntry[] poolEntries;

        public PoolEntry[] PoolEntries => poolEntries;

#if UNITY_EDITOR
        public void Refresh()
        {
            Debug.Log("Start Generating Pool Names...");
            PoolNamesGenerator.Write(this, poolEntries);
            Debug.Log("Generating Pool Names Finished!");

            AssetDatabase.Refresh(ImportAssetOptions.Default);
        }
#endif
    }

}
