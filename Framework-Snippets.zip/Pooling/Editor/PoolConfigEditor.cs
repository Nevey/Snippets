﻿using UnityEditor;
using UnityEngine;

namespace CardboardCore.Pooling
{
    [CustomEditor(typeof(PoolConfig))]
    public class PoolConfigEditor : Editor
    {
        private PoolConfig poolConfig;
		
        private void OnEnable()
        {
            poolConfig = (PoolConfig)target;
        }

        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();

            EditorGUILayout.Space();

            if(GUILayout.Button("Force Refresh"))
            {
                poolConfig.Refresh();
            }
        }
    }

}