﻿namespace Stranded.Stats
{
    public enum StatType
    {
        Stamina,
        Fed,
        Health,
        Temperature,
        Relaxed
    }
}