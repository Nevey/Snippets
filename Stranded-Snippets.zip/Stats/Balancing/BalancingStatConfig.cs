﻿using System;
using GD.MinMaxSlider;
using Stranded.Characters.Needs;
using UnityEngine;

namespace Stranded.Stats
{
    [Serializable]
    public class BalancingStatConfig
    {
        [SerializeField] private StatType statType;
        [SerializeField, MinMaxSlider(0, 60)] private Vector2 safeRange;
        [SerializeField, MinMaxSlider(0, 60)] private Vector2 limitRange;
        [SerializeField] private int startValue;
        [SerializeField] private CharacterNeedType incrementValueCharacterNeedType;
        [SerializeField] private CharacterNeedType decrementValueCharacterNeedType;

        public StatType StatType => statType;
        public Vector2 SafeRange => safeRange;
        public Vector2 LimitRange => limitRange;
        public int StartValue => startValue;
        public CharacterNeedType IncrementValueCharacterNeedType => incrementValueCharacterNeedType;
        public CharacterNeedType DecrementValueCharacterNeedType => decrementValueCharacterNeedType;
    }
}