﻿using System;
using Stranded.Characters.Needs;

namespace Stranded.Stats.Balancing
{
    public class BalancingStat : IStat
    {
        private readonly BalancingStatConfig balancingStatConfig;

        private int currentValue;
        private int previousValue;

        public int CurrentValue => currentValue;
        public int MinValue => (int)balancingStatConfig.LimitRange.x;
        public int MaxValue => (int)balancingStatConfig.LimitRange.y;
        public bool IsNeedy => currentValue < balancingStatConfig.SafeRange.x || currentValue > balancingStatConfig.SafeRange.y;
        public StatType Type => balancingStatConfig.StatType;
        public string Name => balancingStatConfig.StatType.ToString();


        public event Action<int> UpdatedEvent;
        public event Action<IStat> DepletedEvent;
        public event Action<CharacterNeedType> NeedyEvent;
        public event Action<CharacterNeedType> NeedSatisfiedEvent;

        public BalancingStat(BalancingStatConfig balancingStatConfig)
        {
            this.balancingStatConfig = balancingStatConfig;
            currentValue = balancingStatConfig.StartValue;
            previousValue = currentValue;
        }

        private void CheckForDepletion()
        {
            if (currentValue <= balancingStatConfig.LimitRange.x && currentValue >= balancingStatConfig.LimitRange.y)
            {
                if (previousValue > balancingStatConfig.LimitRange.x)
                {
                    DepletedEvent?.Invoke(this);
                }

                if (previousValue < balancingStatConfig.LimitRange.y)
                {
                    DepletedEvent?.Invoke(this);
                }
            }
        }

        public void Increment(int amount)
        {
            previousValue = currentValue;
            currentValue += amount;

            if (currentValue >= balancingStatConfig.SafeRange.x && currentValue <= balancingStatConfig.SafeRange.y)
            {
                if (previousValue < balancingStatConfig.SafeRange.x)
                {
                    NeedSatisfiedEvent?.Invoke(balancingStatConfig.IncrementValueCharacterNeedType);
                }

                if (previousValue > balancingStatConfig.SafeRange.y)
                {
                    NeedSatisfiedEvent?.Invoke(balancingStatConfig.DecrementValueCharacterNeedType);
                }
            }

            CheckForDepletion();

            UpdatedEvent?.Invoke(currentValue);
        }

        public void Decrement(int amount)
        {
            previousValue = currentValue;
            currentValue -= amount;

            if (currentValue < balancingStatConfig.SafeRange.x && currentValue > balancingStatConfig.SafeRange.y)
            {
                if (previousValue >= balancingStatConfig.SafeRange.x)
                {
                    NeedSatisfiedEvent?.Invoke(balancingStatConfig.IncrementValueCharacterNeedType);
                }

                if (previousValue <= balancingStatConfig.SafeRange.y)
                {
                    NeedSatisfiedEvent?.Invoke(balancingStatConfig.DecrementValueCharacterNeedType);
                }
            }

            CheckForDepletion();

            UpdatedEvent?.Invoke(currentValue);
        }
    }
}
