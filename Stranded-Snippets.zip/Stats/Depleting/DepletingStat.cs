﻿using System;
using Stranded.Characters.Needs;

namespace Stranded.Stats.Depleting
{
    public class DepletingStat : IStat
    {
        private readonly DepletingStatConfig depletingStatConfig;

        private int currentValue;
        private int previousValue;
        private float currentInterval;

        public bool CanDeplete => depletingStatConfig.AutoUpdateInterval > 0f;
        public int MinValue => 0;
        public int MaxValue => depletingStatConfig.MaxValue;
        public int CurrentValue => currentValue;
        public bool IsNeedy => currentValue <= depletingStatConfig.NeedValue;
        public StatType Type => depletingStatConfig.StatType;
        public string Name => depletingStatConfig.StatType.ToString();


        public event Action<int> UpdatedEvent;
        public event Action<IStat> DepletedEvent;
        public event Action<CharacterNeedType> NeedyEvent;
        public event Action<CharacterNeedType> NeedSatisfiedEvent;

        public DepletingStat(DepletingStatConfig depletingStatConfig)
        {
            this.depletingStatConfig = depletingStatConfig;
            currentValue = depletingStatConfig.StartValue;
            previousValue = depletingStatConfig.MaxValue;
        }

        public void AutoUpdate(float interval)
        {
            currentInterval += interval;

            while (currentInterval >= depletingStatConfig.AutoUpdateInterval)
            {
                currentInterval -= depletingStatConfig.AutoUpdateInterval;

                switch (depletingStatConfig.StatAutoUpdateType)
                {
                    case StatAutoUpdateType.Append:
                        Increment(depletingStatConfig.AutoUpdateAmount);
                        break;

                    case StatAutoUpdateType.Deplete:
                        Decrement(depletingStatConfig.AutoUpdateAmount);
                        break;

                    case StatAutoUpdateType.None:
                        // We simply don't do a thing...
                        break;
                }
            }
        }

        public void Increment(int amount)
        {
            currentValue += amount;

            if (previousValue <= depletingStatConfig.SatisfiedValue && currentValue > depletingStatConfig.SatisfiedValue)
            {
                NeedSatisfiedEvent?.Invoke(depletingStatConfig.CharacterNeedType);
            }

            if (currentValue > depletingStatConfig.MaxValue)
            {
                currentValue = depletingStatConfig.MaxValue;
            }

            previousValue = currentValue;

            UpdatedEvent?.Invoke(currentValue);
        }

        public void Decrement(int amount)
        {
            currentValue -= amount;

            if (previousValue > depletingStatConfig.NeedValue && currentValue <= depletingStatConfig.NeedValue)
            {
                NeedyEvent?.Invoke(depletingStatConfig.CharacterNeedType);
            }

            if (currentValue <= 0)
            {
                currentValue = 0;

                if (previousValue > 0)
                {
                    DepletedEvent?.Invoke(this);
                }
            }

            previousValue = currentValue;

            UpdatedEvent?.Invoke(currentValue);
        }
    }
}
