﻿using System;
using Stranded.Characters.Needs;
using UnityEngine;

namespace Stranded.Stats.Depleting
{
    [Serializable]
    public class DepletingStatConfig
    {
        [SerializeField] private StatType statType;
        [SerializeField] private StatAutoUpdateType statAutoUpdateType;
        [SerializeField, Range(0, 100)] private int startValue = 75;
        [SerializeField, Range(0, 100)] private int maxValue = 100;
        [SerializeField, Range(0, 100)] private int needValue = 50;
        [SerializeField, Range(0, 100)] private int satisfiedValue = 75;
        [SerializeField] private float autoUpdateInterval = 5f;
        [SerializeField, Range(0, 100)] private int autoUpdateAmount = 1;
        [SerializeField] private CharacterNeedType characterNeedType;

        public StatType StatType => statType;
        public StatAutoUpdateType StatAutoUpdateType => statAutoUpdateType;
        public int StartValue => startValue;
        public int MaxValue => maxValue;
        public int NeedValue => needValue;
        public int SatisfiedValue => satisfiedValue;
        public float AutoUpdateInterval => autoUpdateInterval;
        public int AutoUpdateAmount => autoUpdateAmount;
        public CharacterNeedType CharacterNeedType => characterNeedType;
    }
}
