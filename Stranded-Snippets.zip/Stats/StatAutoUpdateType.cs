﻿namespace Stranded.Stats
{
    public enum StatAutoUpdateType
    {
        Deplete,
        Append,
        None
    }
}