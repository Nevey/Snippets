﻿using UnityEditor;
using UnityEngine;

namespace Stranded.Stats
{
    [CustomEditor(typeof(StatsController))]
    public class StatsControllerEditor : Editor
    {
        private StatsController statsController;
        private bool isShowing;

        private void OnEnable()
        {
            statsController = (StatsController) target;
        }

        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();

            if (Application.isPlaying && GUILayout.Button("Toggle Stats"))
            {
                if (isShowing)
                {
                    statsController.HideAllStats();
                }
                else
                {
                    statsController.ShowAllStats(4f);
                }

                isShowing = !isShowing;
            }
        }
    }
}