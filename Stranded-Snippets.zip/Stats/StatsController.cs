﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using CardboardCore.DI;
using CardboardCore.Pooling;
using Stranded.Characters.Actions;
using Stranded.Characters.Needs;
using Stranded.Stats.Balancing;
using Stranded.Stats.Depleting;
using Stranded.Stats.View;
using UnityEngine;
using UnityEngine.Serialization;

namespace Stranded.Stats
{
    [RequireComponent(typeof(CharacterActionController))]
    public class StatsController : CardboardCoreBehaviour
    {
        [Header("Depleting Stats")]
        [FormerlySerializedAs("statConfigs")] [SerializeField] private DepletingStatConfig[] depletingStatConfigs;
        [FormerlySerializedAs("depletionUpdateTick")] [SerializeField, Tooltip("In Seconds...")] private float autoUpdateTick = 1f;

        [Header("Balancing Stats")]
        [SerializeField, Tooltip("Only affected by other systems")] private BalancingStatConfig[] balancingStatConfigs;

        [Header("Visuals Settings")]
        [FormerlySerializedAs("poolConfig")] [SerializeField] private PoolConfig statViewPoolConfig;

        [Inject] private PoolController poolController;

        private CharacterActionController characterActionController;

        private readonly Dictionary<StatType, IStat> statsDictionary = new Dictionary<StatType, IStat>();

        private StatsView cachedStatsView;
        private Coroutine alertRoutine;
        protected bool alertMode;

        public IStat[] AllStats => statsDictionary.Values.ToArray();

        public event Action<CharacterNeedType> NeedyEvent;
        public event Action<CharacterNeedType> NeedSatisfiedEvent;

        protected override void Awake()
        {
            base.Awake();

            characterActionController = GetComponent<CharacterActionController>();
            characterActionController.CharacterActionStartedEvent += OnCharacterActionStarted;
            characterActionController.CharacterActionFinishedEvent += OnCharacterActionFinished;

            for (int i = 0; i < depletingStatConfigs.Length; i++)
            {
                DepletingStatConfig depletingStatConfig = depletingStatConfigs[i];

                if (statsDictionary.ContainsKey(depletingStatConfig.StatType))
                {
                    throw Log.Exception($"Duplicate Stat of type <b>{depletingStatConfig.StatType}</b> found on {name}!");
                }

                DepletingStat depletingStat = new DepletingStat(depletingStatConfig);
                depletingStat.NeedyEvent += OnStatNeedy;
                depletingStat.NeedSatisfiedEvent += OnStatNeedSatisfied;

                statsDictionary[depletingStatConfig.StatType] = depletingStat;
            }

            for (int i = 0; i < balancingStatConfigs.Length; i++)
            {
                BalancingStatConfig balancingStatConfig = balancingStatConfigs[i];

                if (statsDictionary.ContainsKey(balancingStatConfig.StatType))
                {
                    throw Log.Exception($"Duplicate Stat of type <b>{balancingStatConfig.StatType}</b> found on {name}!");
                }

                BalancingStat balancingStat = new BalancingStat(balancingStatConfig);
                balancingStat.NeedyEvent += OnStatNeedy;
                balancingStat.NeedSatisfiedEvent += OnStatNeedSatisfied;

                statsDictionary[balancingStatConfig.StatType] = balancingStat;
            }
        }

        protected override void Start()
        {
            base.Start();

            StartCoroutine(StatsAutoUpdateEnumerator());
        }

        protected override void OnDestroy()
        {
            HideStats();

            characterActionController.CharacterActionStartedEvent -= OnCharacterActionStarted;
            characterActionController.CharacterActionFinishedEvent -= OnCharacterActionFinished;

            StopAllCoroutines();

            foreach (var item in statsDictionary)
            {
                item.Value.NeedyEvent -= OnStatNeedy;
                item.Value.NeedSatisfiedEvent -= OnStatNeedSatisfied;
            }

            base.OnDestroy();
        }

        private void OnCharacterActionStarted(CharacterActionType characterActionType)
        {
            // When this character started sleeping, we stop the stat updates
            if (characterActionType != CharacterActionType.Sleep)
            {
                return;
            }

            StopAllCoroutines();
        }

        private void OnCharacterActionFinished(CharacterActionType characterActionType)
        {
            // When this character wakes up again, we start the stat updates
            if (characterActionType != CharacterActionType.Sleep)
            {
                return;
            }

            StartCoroutine(StatsAutoUpdateEnumerator());
        }

        protected StatsView GetStatsView()
        {
            if (cachedStatsView == null)
            {
                cachedStatsView = poolController.Pop<StatsView>(statViewPoolConfig, StatViewPoolConfigNames.StatsViewUI);
                cachedStatsView.SetTarget(transform);

                cachedStatsView.transform.localPosition = Vector3.zero;
            }

            return cachedStatsView;
        }

        private void HideStats()
        {
            poolController.Push(statViewPoolConfig, cachedStatsView);
        }

        private void OnStatNeedy(CharacterNeedType obj)
        {
            NeedyEvent?.Invoke(obj);
        }

        private void OnStatNeedSatisfied(CharacterNeedType obj)
        {
            NeedSatisfiedEvent?.Invoke(obj);
        }

        private IEnumerator StatsAutoUpdateEnumerator()
        {
            while (true)
            {
                yield return new WaitForSeconds(autoUpdateTick);

                foreach (var item in statsDictionary)
                {
                    if (item.Value is DepletingStat depletingStat)
                    {
                        if (depletingStat.CanDeplete)
                        {
                            depletingStat.AutoUpdate(autoUpdateTick);
                        }
                    }
                }
            }
        }

        private IEnumerator AlertEnumerator(float duration, float offset, params IStat[] stats)
        {
            ShowStatsWithoutAlertInterruption(offset, stats);

            yield return new WaitForSeconds(duration);

            alertMode = false;
            HideAllStats();
        }

        public IStat GetStat(StatType statType)
        {
            return statsDictionary.TryGetValue(statType, out IStat stat) ? stat : null;
        }

        public DepletingStat GetDepletingStat(StatType statType)
        {
            if (GetStat(statType) is DepletingStat depletingStat)
            {
                return depletingStat;
            }

            return null;
        }

        public BalancingStat GetBalancingStat(StatType statType)
        {
            if (GetStat(statType) is BalancingStat balancingStat)
            {
                return balancingStat;
            }

            return null;
        }

        public void ShowAllStats(float offset)
        {
            ShowStats(offset, AllStats);
        }

        public void ShowStats(float offset, params IStat[] stats)
        {
            if (alertRoutine != null)
            {
                StopCoroutine(alertRoutine);
            }

            alertMode = false;

            ShowStatsWithoutAlertInterruption(offset, stats);
        }

        public void ShowStatsWithoutAlertInterruption(float offset, params IStat[] stats)
        {
            StatsView statsView = GetStatsView();

            for (int i = 0; i < stats.Length; i++)
            {
                if (!statsDictionary.ContainsKey(stats[i].Type))
                {
                    Log.Error($"Character {gameObject.name} does not contain Stat <b>{stats[i].Name}</b>");
                    continue;
                }

                statsView.RegisterStat(stats[i]);
            }

            statsView.Show(offset);
        }

        public void AlertStats(float duration, float offset, params IStat[] stats)
        {
            alertMode = true;

            if (alertRoutine != null)
            {
                StopCoroutine(alertRoutine);
            }

            alertRoutine = StartCoroutine(AlertEnumerator(duration, offset, stats));
        }

        public void HideAllStats()
        {
            if (cachedStatsView == null)
            {
                // Nothing to hide...
                return;
            }

            // We're alerting... don't hide!
            if (alertMode)
            {
                return;
            }

            cachedStatsView.Hide();
        }
    }
}
