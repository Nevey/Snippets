﻿using CardboardCore.Pooling;
using UnityEngine;
using UnityEngine.UI;

namespace Stranded.Stats.View
{
    public class StatView : MonoBehaviour, IPoolable
    {
        [SerializeField] private Slider slider;

        private IStat stat;

        public IStat Stat => stat;

        public void Init(IStat stat)
        {
            this.stat = stat;
            stat.UpdatedEvent += OnStatUpdated;

            slider.minValue = stat.MinValue;
            slider.maxValue = stat.MaxValue;

            UpdateView();
        }

        private void OnStatUpdated(int currentValue)
        {
            UpdateView();
        }

        private void UpdateView()
        {
            slider.value = stat.CurrentValue;
        }

        public void OnPop()
        {

        }

        public void OnPush()
        {
            stat.UpdatedEvent -= OnStatUpdated;
            stat = null;
        }
    }
}
