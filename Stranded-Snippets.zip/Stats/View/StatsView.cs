﻿using System.Collections.Generic;
using CardboardCore.DI;
using CardboardCore.Pooling;
using UnityEngine;

namespace Stranded.Stats.View
{
    public class StatsView : CardboardCoreBehaviour, IPoolable
    {
        [SerializeField] private PoolConfig poolConfig;
        [SerializeField] private Transform uiParent;

        [Inject] private PoolController poolController;

        public enum StatsViewState
        {
            Hidden,
            Visible
        }

        private Transform target;
        private StatsViewState statsViewState;
        private readonly List<IStat> stats = new List<IStat>();
        private readonly List<StatView> depletableStatViews = new List<StatView>();
        private float offset;

        public StatsViewState CurrentStatsViewState => statsViewState;

        private void LateUpdate()
        {
            if (target == null)
            {
                return;
            }

            Vector3 position = target.position;
            position.y += offset;

            transform.position = position;
        }

        private void SetStatsViewState(StatsViewState statsViewState)
        {
            this.statsViewState = statsViewState;

            switch (statsViewState)
            {
                case StatsViewState.Hidden:
                    HideAllStats();
                    break;

                case StatsViewState.Visible:
                    ShowAllStats();
                    break;
            }
        }

        private void ShowAllStats()
        {
            for (int i = 0; i < stats.Count; i++)
            {
                bool alreadyViewing = false;

                for (int k = 0; k < depletableStatViews.Count; k++)
                {
                    if (depletableStatViews[k].Stat.Type == stats[i].Type)
                    {
                        alreadyViewing = true;
                        break;
                    }
                }

                if (alreadyViewing)
                {
                    continue;
                }

                ShowStatView(stats[i]);
            }
        }

        private void HideAllStats()
        {
            for (int i = depletableStatViews.Count - 1; i >= 0; i--)
            {
                HideStatView(depletableStatViews[i]);
            }
        }

        private void ShowStatView(IStat stat)
        {
            StatView statView = poolController.Pop<StatView>(poolConfig, StatViewPoolConfigNames.StatView, uiParent);
            statView.Init(stat);

            statView.transform.localPosition = Vector3.zero;
            statView.transform.localScale = Vector3.one;
            statView.transform.localRotation = Quaternion.identity;

            depletableStatViews.Add(statView);
        }

        private void HideStatView(StatView statView)
        {
            depletableStatViews.Remove(statView);
            poolController.Push(poolConfig, statView);
        }

        public void SetTarget(Transform target)
        {
            this.target = target;
        }

        public void RegisterStat(IStat stat)
        {
            for (int i = 0; i < stats.Count; i++)
            {
                if (stats[i].Type == stat.Type)
                {
                    return;
                }
            }

            stats.Add(stat);
        }

        public void Hide()
        {
            SetStatsViewState(StatsViewState.Hidden);
            stats.Clear();
        }

        public void Show(float offset)
        {
            this.offset = offset;
            SetStatsViewState(StatsViewState.Visible);
        }

        public void OnPop()
        {

        }

        public void OnPush()
        {
            Hide();
            target = null;
        }
    }
}
