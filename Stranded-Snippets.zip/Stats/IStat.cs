﻿using System;
using Stranded.Characters.Needs;

namespace Stranded.Stats
{
    public interface IStat
    {
        int CurrentValue { get; }
        int MinValue { get; }
        int MaxValue { get; }
        bool IsNeedy { get; }
        StatType Type { get; }
        string Name { get; }

        event Action<int> UpdatedEvent;
        event Action<IStat> DepletedEvent;
        event Action<CharacterNeedType> NeedyEvent;
        event Action<CharacterNeedType> NeedSatisfiedEvent;

        void Increment(int amount);
        void Decrement(int amount);
    }
}
