using Stranded.Characters.Rotation;
using UnityEngine;
using Stranded.Characters.Player.Combat.Attacking;
using Stranded.Characters.Combat.Attacking;

namespace Stranded.Characters.Player.Movement
{
    [AddComponentMenu("Stranded/Characters/Player/PlayerRotation")]
    [RequireComponent(typeof(PlayerMovementInput))]
    [RequireComponent(typeof(PlayerAttackController))]
    public class PlayerRotation : CharacterRotation
    {
        [Header("Optional References")]
        [SerializeField] private TargetingController targetingController;

        private PlayerMovementInput playerMovementInput;
        private PlayerAttackController playerAttackController;

        private Vector3 euler;
        private Quaternion rotation;

        private bool hasTarget;
        private bool isAttacking;

        protected override void Awake()
        {
            base.Awake();

            if (targetingController != null)
            {
                targetingController.TargetableSelectedEvent += OnTargetableSelected;
                targetingController.TargetableUnselectedEvent += OnTargetableUnselected;
            }

            playerMovementInput = GetComponent<PlayerMovementInput>();
            playerMovementInput.MovementInputUpdatedEvent += OnMovementInputUpdated;

            playerAttackController = GetComponent<PlayerAttackController>();
            playerAttackController.AttackStartedEvent += OnAttackStarted;
            playerAttackController.AttackFinishedEvent += OnAttackFinished;
        }

        private void OnDestroy()
        {
            if (targetingController != null)
            {
                targetingController.TargetableSelectedEvent -= OnTargetableSelected;
                targetingController.TargetableUnselectedEvent -= OnTargetableUnselected;
            }

            playerMovementInput.MovementInputUpdatedEvent -= OnMovementInputUpdated;

            playerAttackController.AttackStartedEvent -= OnAttackStarted;
            playerAttackController.AttackFinishedEvent -= OnAttackFinished;
        }

        private void OnTargetableSelected()
        {
            hasTarget = true;
        }

        private void OnTargetableUnselected()
        {
            hasTarget = false;
        }

        private void OnMovementInputUpdated(Vector2 input)
        {
            // Player is not necessarily only attacking when targeting
            if (hasTarget || isAttacking)
            {
                return;
            }

            if (input != Vector2.zero)
            {
                euler.x = input.x;
                euler.z = input.y;
            }

            if (euler == Vector3.zero)
            {
                return;
            }

            rotation = Quaternion.LookRotation(-euler, Vector3.up);
            SetTargetRotation(rotation);
        }

        private void OnAttackStarted(AttackArgs attackArgs)
        {
            isAttacking = true;
            mayRotate = false;
        }

        private void OnAttackFinished()
        {
            isAttacking = false;
            mayRotate = true;
        }
    }
}
