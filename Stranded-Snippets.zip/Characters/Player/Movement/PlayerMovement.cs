using Stranded.Characters.Combat.Attacking;
using Stranded.Characters.Movement;
using Stranded.Characters.Player.Combat.Attacking;
using UnityEngine;

namespace Stranded.Characters.Player.Movement
{
    [AddComponentMenu("Stranded/Characters/Player/PlayerMovement")]
    [RequireComponent(typeof(PlayerMovementInput))]
    [RequireComponent(typeof(PlayerAttackController))]
    public class PlayerMovement : CharacterMovement
    {
        [Header("Player Specific Settings")]
        [SerializeField] private Collider defaultCollider;

        private PlayerMovementInput playerMovementInput;
        private PlayerAttackController playerAttackController;

        private Vector3 direction;

        private bool isAttacking;
        private bool mayRollDuringAttack;

        protected override void Awake()
        {
            base.Awake();

            playerMovementInput = GetComponent<PlayerMovementInput>();
            playerMovementInput.MovementInputUpdatedEvent += OnMovementInputUpdated;

            playerAttackController = GetComponent<PlayerAttackController>();
            playerAttackController.AttackStartedEvent += OnAttackStarted;
            playerAttackController.AttackFinishedEvent += OnAttackEnded;
        }

        protected override void OnDestroy()
        {
            playerMovementInput.MovementInputUpdatedEvent -= OnMovementInputUpdated;

            playerAttackController.AttackStartedEvent -= OnAttackStarted;
            playerAttackController.AttackFinishedEvent -= OnAttackEnded;

            base.OnDestroy();
        }

        private void OnMovementInputUpdated(Vector2 input)
        {
            direction.x = input.x;
            direction.z = input.y;
            MoveInDirection(direction);
        }

        private void OnAttackStarted(AttackArgs attackArgs)
        {
            isAttacking = true;
        }

        private void OnAttackEnded()
        {
            isAttacking = false;
        }
    }
}
