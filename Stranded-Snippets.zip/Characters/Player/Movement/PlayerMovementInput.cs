﻿using System;
using CardboardCore.DI;
using CardboardCore.InputSystem;
using Stranded.Cameras;
using Stranded.Characters.Animations;
using UnityEngine;

namespace Stranded.Characters.Player.Movement
{
    [AddComponentMenu("Stranded/Characters/Player/Player Movement Input")]
    public class PlayerMovementInput : PlayerInputTranslator
    {
        [Inject] private CameraManager cameraManager;

        [AnimationLink] private Vector2 inputDelta;

        private Vector2 cameraBasedInputDelta;

        protected override string ActionID => "Move";

        public event Action<Vector2> MovementInputUpdatedEvent;

        private void Update()
        {
            Vector3 worldInput = new Vector3(-inputDelta.x, 0f, inputDelta.y);
            cameraManager.ProjectOnActiveCameraPlane(ref worldInput);

            cameraBasedInputDelta.x = worldInput.x;
            cameraBasedInputDelta.y = worldInput.z;

            MovementInputUpdatedEvent?.Invoke(cameraBasedInputDelta);
        }

        protected override void OnPlayerInputPerformed(PlayerInputTranslatorData playerInputTranslatorData)
        {
            inputDelta = playerInputTranslatorData.GetValue<Vector2>();
        }

        protected override void OnPlayerInputCanceled()
        {
            inputDelta = Vector2.zero;
        }
    }
}
