﻿using System.Collections;
using System.Collections.Generic;
using CardboardCore.DI;
using CardboardCore.UI;
using Stranded.ButtonPrompts;
using Stranded.Items;
using UnityEngine;

namespace Scripts.Player.Items
{
    [RequireComponent(typeof(SphereCollider))]
    [RequireComponent(typeof(PlayerPickupInput))]
    public class PlayerPickupController : CardboardCoreBehaviour
    {
        [Header("Storage Settings")]
        [SerializeField] private ItemStorage itemStorage;

        [Inject] private UIController uiController;

        private SphereCollider sphereCollider;
        private PlayerPickupInput playerPickupInput;
        private readonly List<ItemWorldInstance> itemsInRange = new List<ItemWorldInstance>();
        private Coroutine updateRoutine;
        private ItemWorldInstance targetedItem;

        public ItemStorage ItemStorage => itemStorage;

        protected override void Awake()
        {
            base.Awake();

            sphereCollider = GetComponent<SphereCollider>();
            sphereCollider.isTrigger = true;

            playerPickupInput = GetComponent<PlayerPickupInput>();
            playerPickupInput.PickupInputEvent += OnPickupInput;
        }

        protected override void OnDestroy()
        {
            playerPickupInput.PickupInputEvent -= OnPickupInput;
            StopUpdateRoutine();

            base.OnDestroy();
        }

        private void OnTriggerEnter(Collider other)
        {
            // Colliders are always added to the visual part of the item, which is a child of the ItemWorldInstance
            ItemWorldInstance itemWorldInstance = other.transform.GetComponentInParent<ItemWorldInstance>();

            if (itemWorldInstance == null
                || itemsInRange.Contains(itemWorldInstance))
            {
                return;
            }

            itemsInRange.Add(itemWorldInstance);

            if (itemsInRange.Count == 1)
            {
                StartUpdateRoutine();
            }
        }

        private void OnTriggerExit(Collider other)
        {
            // Colliders are always added to the visual part of the item, which is a child of the ItemWorldInstance
            ItemWorldInstance itemWorldInstance = other.transform.GetComponentInParent<ItemWorldInstance>();

            if (itemWorldInstance == null
                || !itemsInRange.Contains(itemWorldInstance))
            {
                return;
            }

            itemsInRange.Remove(itemWorldInstance);

            if (targetedItem == itemWorldInstance)
            {
                HidePrompt();
                targetedItem = null;
            }

            if (itemsInRange.Count == 0)
            {
                StopUpdateRoutine();
            }
        }

        private void StartUpdateRoutine()
        {
            if (updateRoutine != null)
            {
                return;
            }

            updateRoutine = StartCoroutine(UpdateEnumerator());
        }

        private void StopUpdateRoutine()
        {
            if (updateRoutine == null)
            {
                return;
            }

            StopCoroutine(updateRoutine);
            updateRoutine = null;
        }

        private IEnumerator UpdateEnumerator()
        {
            while (itemsInRange.Count > 0)
            {
                targetedItem = GetNearestItem();

                ShowPrompt();

                yield return null;
            }
        }

        private ItemWorldInstance GetNearestItem()
        {
            float nearestItemDistance = sphereCollider.radius * 2f;
            ItemWorldInstance nearestItem = null;

            for (int i = 0; i < itemsInRange.Count; i++)
            {
                float distance = Vector3.Distance(itemsInRange[i].transform.position, transform.position);

                if (distance < nearestItemDistance)
                {
                    nearestItem = itemsInRange[i];
                    nearestItemDistance = distance;
                }
            }

            return nearestItem;
        }

        private void ShowPrompt()
        {
            uiController.GetWidget<ButtonPromptWidget>().ShowPromptText(targetedItem.transform, playerPickupInput.Prompt, true);
        }

        private void HidePrompt()
        {
            uiController.GetWidget<ButtonPromptWidget>().HidePrompt(targetedItem.transform);
        }

        private void OnPickupInput()
        {
            if (targetedItem == null)
            {
                return;
            }

            // TODO: Check if OnTriggerExit is called so we don't have to do this here
            itemsInRange.Remove(targetedItem);

            if (itemsInRange.Count == 0)
            {
                StopUpdateRoutine();
            }

            HidePrompt();

            targetedItem.Pickup(itemStorage);
            targetedItem = null;
        }
    }
}
