﻿using System;
using CardboardCore.InputSystem;
using UnityEngine.InputSystem;

namespace Scripts.Player.Items
{
    public class PlayerPickupInput : PlayerInputTranslatorString
    {
        protected override string ActionID => "Pickup";

        public event Action PickupInputEvent;

        protected override void OnPlayerInputPerformed(PlayerInputTranslatorData playerInputTranslatorData)
        {
            if (playerInputTranslatorData.InputActionPhase == InputActionPhase.Started)
            {
                PickupInputEvent?.Invoke();
            }
        }
    }
}
