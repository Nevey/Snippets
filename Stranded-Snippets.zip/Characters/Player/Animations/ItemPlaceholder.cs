using UnityEngine;

namespace Stranded.Characters.Animations
{
    public class ItemPlaceholder : MonoBehaviour
    {
        [SerializeField] private Vector3 euler;

        public Vector3 Euler => euler.normalized;

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawRay(transform.position, Euler);
        }
    }
}
