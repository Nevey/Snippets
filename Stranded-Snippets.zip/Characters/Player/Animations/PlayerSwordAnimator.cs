using DG.Tweening;
using Stranded.Characters.Combat.Attacking;
using Stranded.Characters.Combat.Defending;
using Stranded.Characters.Player.Combat.Attacking;
using Stranded.Characters.Player.Combat.Defending;
using UnityEngine;

namespace Stranded.Characters.Animations
{
    // TODO: Make this part of the actual sword/melee weapon
    [RequireComponent(typeof(PlayerAttackController))]
    [RequireComponent(typeof(PlayerBlockController))]
    public class PlayerSwordAnimator : MonoBehaviour
    {
        [Header("Sword")]
        [SerializeField] private Transform sword;
        [SerializeField] private ItemPlaceholder holdPlaceholder;
        [SerializeField] private ItemPlaceholder leftPlaceholder;
        [SerializeField] private ItemPlaceholder rightPlaceholder;
        [SerializeField] private Ease moveEase;
        [SerializeField] private Ease rotateEase;

        [Header("Shield")]
        [SerializeField] private Transform shield;
        [SerializeField] private ItemPlaceholder defaultShieldPlaceholder;
        [SerializeField] private ItemPlaceholder leftShieldPlaceholder;
        [SerializeField] private ItemPlaceholder holdShieldPlaceholder;

        [Header("Trail Visuals")]
        [SerializeField] private TrailRenderer trailEffect;

        private PlayerAttackController playerAttackController;
        private PlayerBlockController playerBlockController;
        private AttackArgs currentAttackArgs;
        private BlockArgs currentBlockArgs;

        private void Awake()
        {
            playerAttackController = GetComponent<PlayerAttackController>();
            playerAttackController.AttackStartedEvent += OnAttackStarted;
            playerAttackController.AttackFinishedEvent += OnAttackFinished;
            playerAttackController.ChainFinishedEvent += OnChainFinished;

            playerBlockController = GetComponent<PlayerBlockController>();
            playerBlockController.BlockUpdatedEvent += OnBlockUpdated;

            trailEffect.emitting = false;
        }

        private void OnBlockUpdated(BlockArgs obj)
        {
            currentBlockArgs = obj;

            if (obj.BlockState == BlockState.Block)
            {
                AnimateItemTo(shield, holdShieldPlaceholder, 0.1f);
            }

            if (obj.BlockState == BlockState.None)
            {
                AnimateItemTo(shield, defaultShieldPlaceholder, 0.1f);
            }
        }

        private void OnDestroy()
        {
            playerAttackController.AttackStartedEvent -= OnAttackStarted;
            playerAttackController.AttackFinishedEvent -= OnAttackFinished;
            playerAttackController.ChainFinishedEvent -= OnChainFinished;

            playerBlockController.BlockUpdatedEvent -= OnBlockUpdated;
        }

        private void Start()
        {
            AnimateItemTo(sword, holdPlaceholder, 0f);
            AnimateItemTo(shield, defaultShieldPlaceholder, 0f);
        }

        private void OnAttackStarted(AttackArgs attackArgs)
        {
            currentAttackArgs = attackArgs;

            switch (attackArgs.attackState)
            {
                case AttackState.InitialSweep:

                    AnimateItemTo(sword, rightPlaceholder, 0f);
                    AnimateItemTo(sword, leftPlaceholder, attackArgs.attackDuration);

                    if (currentBlockArgs.BlockState == BlockState.None)
                    {
                        AnimateItemTo(shield, leftShieldPlaceholder, attackArgs.attackDuration);
                    }

                    break;

                case AttackState.SweepRightToLeft:

                    AnimateItemTo(sword, leftPlaceholder, attackArgs.attackDuration);

                    if (currentBlockArgs.BlockState == BlockState.None)
                    {
                        AnimateItemTo(shield, leftShieldPlaceholder, attackArgs.attackDuration);
                    }

                    break;

                case AttackState.SweepLeftToRight:

                    AnimateItemTo(sword, rightPlaceholder, attackArgs.attackDuration);

                    if (currentBlockArgs.BlockState == BlockState.None)
                    {
                        AnimateItemTo(shield, defaultShieldPlaceholder, attackArgs.attackDuration);
                    }

                    break;
            }

            trailEffect.emitting = true;
        }

        private void OnAttackFinished()
        {
            trailEffect.emitting = false;
        }

        private void OnChainFinished()
        {
            AnimateItemTo(sword, holdPlaceholder, currentAttackArgs.cooldownDuration);

            if (currentBlockArgs.BlockState == BlockState.None)
            {
                AnimateItemTo(shield, defaultShieldPlaceholder, currentAttackArgs.cooldownDuration);
            }
        }

        private void AnimateItemTo(Transform target, ItemPlaceholder placeholder, float duration)
        {
            Vector3 euler = placeholder.Euler;
            // euler.y *= -1f;
            Quaternion targetRotation = Quaternion.LookRotation(euler, Vector3.up);

            if (duration == 0f)
            {
                target.position = placeholder.transform.position;
                target.localRotation = targetRotation;

                return;
            }

            target.DOLocalMove(placeholder.transform.localPosition, duration).SetEase(moveEase);
            target.DOLocalRotateQuaternion(targetRotation, duration).SetEase(rotateEase);
        }
    }
}
