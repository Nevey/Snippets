using CardboardCore.DI;
using Scripts.Player.Items;

namespace Stranded.Characters.Player
{
    public class PlayerController : CardboardCoreBehaviour
    {
        [Inject] private PlayerRegistry playerRegistry;

        private PlayerPickupController playerPickupController;

        public PlayerPickupController PlayerPickupController => playerPickupController;

        protected override void Awake()
        {
            base.Awake();
            playerRegistry.RegisterPlayer(this);

            playerPickupController = GetComponentInChildren<PlayerPickupController>();
        }

        protected override void OnDestroy()
        {
            playerRegistry.UnregisterPlayer(this);
            base.OnDestroy();
        }
    }
}
