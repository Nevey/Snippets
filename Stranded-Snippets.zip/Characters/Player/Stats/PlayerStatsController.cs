﻿using Stranded.Characters.Player.Input;
using Stranded.Stats;
using Stranded.Stats.View;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Stranded.Characters.Player.Stats
{
    [RequireComponent(typeof(PlayerStatsInput))]
    public class PlayerStatsController : StatsController
    {
        private PlayerStatsInput playerStatsInput;

        protected override void Awake()
        {
            base.Awake();

            playerStatsInput = GetComponent<PlayerStatsInput>();
            playerStatsInput.InputEvent += OnStatsInput;
        }

        protected override void OnDestroy()
        {
            playerStatsInput.InputEvent -= OnStatsInput;

            base.OnDestroy();
        }

        private void Update()
        {
#if DEBUG
            if (Keyboard.current.digit1Key.wasPressedThisFrame)
            {
                GetStat(StatType.Health).Increment(25);
            }

            if (Keyboard.current.digit2Key.wasPressedThisFrame)
            {
                GetStat(StatType.Stamina).Increment(25);
            }

            if (Keyboard.current.digit3Key.wasPressedThisFrame)
            {
                GetStat(StatType.Temperature).Increment(1);
            }

            if (Keyboard.current.digit4Key.wasPressedThisFrame)
            {
                GetStat(StatType.Temperature).Increment(1);
            }
#endif
        }

        private void OnStatsInput()
        {
            StatsView statsView = GetStatsView();

            if (statsView.CurrentStatsViewState == StatsView.StatsViewState.Hidden || alertMode)
            {
                ShowAllStats(5f);
            }
            else
            {
                HideAllStats();
            }
        }
    }
}
