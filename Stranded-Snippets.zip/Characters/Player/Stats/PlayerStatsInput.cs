﻿using System;
using CardboardCore.InputSystem;
using UnityEngine.InputSystem;

namespace Stranded.Characters.Player.Input
{
    public class PlayerStatsInput : PlayerInputTranslator
    {
        protected override string ActionID => "Stats";

        public event Action InputEvent;

        protected override void OnPlayerInputPerformed(PlayerInputTranslatorData playerInputTranslatorData)
        {
            if (playerInputTranslatorData.InputActionPhase != InputActionPhase.Started)
            {
                return;
            }

            InputEvent?.Invoke();
        }
    }
}
