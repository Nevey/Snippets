using System.Collections.Generic;
using System.Collections.ObjectModel;
using CardboardCore.DI;

namespace Stranded.Characters.Player
{
    [Injectable(Singleton = true)]
    public class PlayerRegistry
    {
        private PlayerController localPlayer;
        private List<PlayerController> players = new List<PlayerController>();

        public PlayerController LocalPlayer => localPlayer;
        public ReadOnlyCollection<PlayerController> Players => players.AsReadOnly();

        public void RegisterPlayer(PlayerController playerController, bool isLocal = true)
        {
            players.Add(playerController);

            if (isLocal)
            {
                localPlayer = playerController;
            }
        }

        public void UnregisterPlayer(PlayerController playerController, bool isLocal = true)
        {
            players.Remove(playerController);

            if (isLocal)
            {
                localPlayer = null;
            }
        }
    }
}
