﻿using System;
using CardboardCore.InputSystem;
using Stranded.Characters.Animations;
using UnityEngine.InputSystem;

namespace Stranded.Characters.Player.Combat.Attacking
{
    public class PlayerAttackInput : PlayerInputTranslator
    {
        protected override string ActionID => "Fire";

        [AnimationLink] private bool didAttackLastFrame;
        private bool didCancelAttackLastFrame;

        public event Action InputStartedEvent;
        public event Action InputEndedEvent;

        protected override void OnPlayerInputPerformed(PlayerInputTranslatorData playerInputTranslatorData)
        {
            switch (playerInputTranslatorData.InputActionPhase)
            {
                case InputActionPhase.Started:
                    didAttackLastFrame = true;
                    InputStartedEvent?.Invoke();
                    break;

                case InputActionPhase.Canceled:
                    didCancelAttackLastFrame = true;
                    InputEndedEvent?.Invoke();
                    break;
            }
        }

        private void Update()
        {
            if (didAttackLastFrame)
            {
                didAttackLastFrame = false;
            }

            if (didCancelAttackLastFrame)
            {
                didCancelAttackLastFrame = false;
            }
        }
    }
}
