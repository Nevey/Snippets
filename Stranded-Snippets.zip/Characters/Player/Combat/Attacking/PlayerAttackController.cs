﻿using Stranded.Characters.Combat.Attacking;
using Stranded.Characters.Player.Stats;
using Stranded.Stats;
using UnityEngine;

namespace Stranded.Characters.Player.Combat.Attacking
{
    [RequireComponent(typeof(PlayerAttackInput))]
    [RequireComponent(typeof(PlayerStatsController))]
    public class PlayerAttackController : SweepAttackController
    {
        [Header("Player Attack Settings")]
        [SerializeField] private StatType attackRequiredStatType;
        [SerializeField] private int attackStatCost = 5;

        private PlayerAttackInput playerAttackInput;
        private StatsController statsController;
        private IStat requiredStat;

        private Vector3 previousVelocity;

        protected override void Awake()
        {
            base.Awake();

            playerAttackInput = GetComponent<PlayerAttackInput>();
            playerAttackInput.InputStartedEvent += OnInputStarted;

            statsController = GetComponent<StatsController>();
            requiredStat = statsController.GetStat(attackRequiredStatType);
        }

        private void OnDestroy()
        {
            playerAttackInput.InputStartedEvent -= OnInputStarted;
        }

        private void OnInputStarted()
        {
            if (requiredStat.CurrentValue < attackStatCost)
            {
                statsController.AlertStats(2f, 5f, requiredStat);
                return;
            }

            if (TryStartAttack())
            {
                requiredStat.Decrement(attackStatCost);
            }
        }
    }
}
