using System;
using CardboardCore.InputSystem;
using UnityEngine.InputSystem;

namespace Stranded.Characters.Player.Combat.Targeting
{
    public class PlayerSelectTargetInput : PlayerInputTranslator
    {
        protected override string ActionID => "SelectTarget";

        public event Action InputStartedEvent;

        protected override void OnPlayerInputPerformed(PlayerInputTranslatorData playerInputTranslatorData)
        {
            if (playerInputTranslatorData.InputActionPhase == InputActionPhase.Started)
            {
                InputStartedEvent?.Invoke();
            }
        }
    }
}
