using Stranded.Characters.Combat.Targeting;
using UnityEngine;

namespace Stranded.Characters.Player.Combat.Targeting
{
    [RequireComponent(typeof(PlayerSelectTargetInput))]
    [RequireComponent(typeof(PlayerUnselectTargetInput))]
    public class PlayerTargetingController : TargetingController
    {
        private PlayerSelectTargetInput playerSelectTargetInput;
        private PlayerUnselectTargetInput playerUnselectTargetInput;

        protected override void Awake()
        {
            base.Awake();

            playerSelectTargetInput = GetComponent<PlayerSelectTargetInput>();
            playerUnselectTargetInput = GetComponent<PlayerUnselectTargetInput>();

            playerSelectTargetInput.InputStartedEvent += OnPlayerSelectTargetInput;
            playerUnselectTargetInput.InputStartedEvent += OnPlayerUnselectTargetInput;
        }

        protected override void OnDestroy()
        {
            playerSelectTargetInput.InputStartedEvent -= OnPlayerSelectTargetInput;
            playerUnselectTargetInput.InputStartedEvent -= OnPlayerUnselectTargetInput;

            base.OnDestroy();
        }

        private void OnPlayerSelectTargetInput()
        {
            SelectNextTarget(TargetableFlags.Player);
        }

        private void OnPlayerUnselectTargetInput()
        {
            UnselectCurrentTarget();
        }
    }
}
