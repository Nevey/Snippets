using System;
using CardboardCore.InputSystem;
using UnityEngine.InputSystem;

namespace Stranded.Characters.Player.Combat.Targeting
{
    public class PlayerUnselectTargetInput : PlayerInputTranslator
    {
        protected override string ActionID => "UnselectTarget";

        public event Action InputStartedEvent;

        protected override void OnPlayerInputPerformed(PlayerInputTranslatorData playerInputTranslatorData)
        {
            if (playerInputTranslatorData.InputActionPhase == InputActionPhase.Started)
            {
                InputStartedEvent?.Invoke();
            }
        }
    }
}
