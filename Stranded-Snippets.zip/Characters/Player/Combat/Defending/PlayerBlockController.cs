using Stranded.Characters.Combat.Defending;
using UnityEngine;

namespace Stranded.Characters.Player.Combat.Defending
{
    [RequireComponent(typeof(PlayerBlockInput))]
    public class PlayerBlockController : BlockController
    {
        private PlayerBlockInput playerBlockInput;

        private void Awake()
        {
            playerBlockInput = GetComponent<PlayerBlockInput>();

            playerBlockInput.InputStartedEvent += InputStarted;
            playerBlockInput.InputEndedEvent += InputEnded;
        }

        private void OnDestroy()
        {
            playerBlockInput.InputStartedEvent -= InputStarted;
            playerBlockInput.InputEndedEvent -= InputEnded;
        }

        private void InputStarted()
        {
            TryBlock();
        }

        private void InputEnded()
        {
            TryStopBlock();
        }
    }
}
