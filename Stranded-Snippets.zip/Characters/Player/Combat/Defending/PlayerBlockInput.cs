using System;
using CardboardCore.InputSystem;
using UnityEngine.InputSystem;

namespace Stranded.Characters.Player.Combat.Defending
{
    public class PlayerBlockInput : PlayerInputTranslator
    {
        protected override string ActionID => "Block";

        public event Action InputStartedEvent;
        public event Action InputEndedEvent;

        protected override void OnPlayerInputPerformed(PlayerInputTranslatorData playerInputTranslatorData)
        {
            switch (playerInputTranslatorData.InputActionPhase)
            {
                case InputActionPhase.Started:
                    InputStartedEvent?.Invoke();
                    break;

                case InputActionPhase.Canceled:
                    InputEndedEvent?.Invoke();
                    break;
            }
        }
    }
}
