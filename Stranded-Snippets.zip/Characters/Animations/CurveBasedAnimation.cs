﻿using System;
using DG.Tweening;
using UnityEngine;

namespace Stranded.Characters.Animations
{
    [Serializable]
    public class CurveBasedAnimation
    {
        [SerializeField] private AnimationCurve animationCurve;
        [SerializeField] private float curveValueMultiplier;
        [SerializeField] private AnimationType animationType;
        [SerializeField] private AnimationAxis animationAxis;
        [SerializeField] private bool smoothAnimation;
        [SerializeField] private float smoothDuration = 0.1f;
        [SerializeField] private float resetDuration = 0.1f;

        private enum AnimationType
        {
            Position,
            Rotation
        }

        private enum AnimationAxis
        {
            X,
            Y,
            Z
        }

        private Transform body;
        private float evaluationValue;
        private Vector3 currentVelocity;

        protected void Update()
        {
            switch (animationType)
            {
                case AnimationType.Position:
                    body.localPosition = UpdateVector(body.localPosition);
                    break;

                case AnimationType.Rotation:
                    body.localEulerAngles = UpdateVector(body.localEulerAngles);
                    break;
            }
        }

        private Vector3 UpdateVector(Vector3 baseVector)
        {
            Vector3 targetVector = FilterVector(GetTargetValue(), baseVector);

            if (smoothAnimation)
            {
                if (animationType == AnimationType.Rotation)
                {
                    Quaternion newRotation = Quaternion.RotateTowards(Quaternion.Euler(baseVector), Quaternion.Euler(targetVector), smoothDuration);
                    return newRotation.eulerAngles;
                }

                return Vector3.SmoothDamp(baseVector, targetVector, ref currentVelocity, smoothDuration);
            }

            return targetVector;
        }

        private float GetTargetValue()
        {
            float value = animationCurve.Evaluate(evaluationValue);
            return value * curveValueMultiplier;
        }

        private Vector3 FilterVector(float targetValue, Vector3 vector)
        {
            vector.x = animationAxis == AnimationAxis.X ? targetValue : vector.x;
            vector.y = animationAxis == AnimationAxis.Y ? targetValue : vector.y;
            vector.z = animationAxis == AnimationAxis.Z ? targetValue : vector.z;
            return vector;
        }

        public void Init(Transform body)
        {
            this.body = body;
        }

        public void SetCurveEvaluationValue(float value)
        {
            evaluationValue = value;
            Update();
        }

        public virtual void Reset()
        {
            evaluationValue = 0f;

            // TODO: figure out why this seems to feel good even if it's called like an update loop...

            switch (animationType)
            {
                case AnimationType.Position:
                    body.DOLocalMove(UpdateVector(body.localPosition), resetDuration);
                    break;

                case AnimationType.Rotation:
                    body.DOLocalRotate(UpdateVector(body.localEulerAngles), resetDuration);
                    break;
            }
        }

        public virtual void Validate()
        {
            for (int i = 0; i < animationCurve.length; i++)
            {
                float keyTime = animationCurve.keys[i].time;

                if (keyTime < 0 || keyTime > 1)
                {
                    Log.Error($"An AnimationCurve has a key with it's time out of bounds: Time = {keyTime}");
                }
            }
        }
    }
}
