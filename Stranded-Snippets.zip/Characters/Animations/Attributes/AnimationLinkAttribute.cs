using System;

namespace Stranded.Characters.Animations
{
    [AttributeUsage(AttributeTargets.Field)]
    public class AnimationLinkAttribute : Attribute
    {
    }
}
