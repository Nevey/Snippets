using System;
using System.Reflection;
using CardboardCore.Utilities;
using UnityEngine;

namespace Stranded.Characters.Animations
{
    public enum AnimationEffect
    {
        Default,
        Append,
        Override,
    }

    public enum AnimationType
    {
        Position,
        Rotation
    }

    public enum AnimationAxis
    {
        X,
        Y,
        Z
    }

    /// <summary>
    /// ScriptableObject which will be created during editor time when creating animation configurations
    /// </summary>
    [Serializable]
    public class AnimationConfig : IComparable<AnimationConfig>
    {
        // Data set by tool
        [SerializeField] private MonoBehaviour linkedObject;
        [SerializeField] private string linkedFieldName;
        [SerializeField] private string linkedTypeName;

        // Used in editor tool
        [SerializeField] private bool filterBasedOnField = true;
        [SerializeField, HideInInspector] private string animationName;
        [SerializeField, HideInInspector] private bool isFoldedOut;
        [SerializeField, HideInInspector] private int selectedAnimationHandlerIndex;

        // Data tweakable via editor
        [SerializeField] private AnimationEffect animationEffect;
        [SerializeField] private int priority;
        [SerializeField] private AnimationCurve animationCurve;
        [SerializeField] private float curveMultiplier = 1f;
        [SerializeField] private float curveTimeMultiplier = 1f;
        [SerializeField] private AnimationType animationType;
        [SerializeField] private AnimationAxis animationAxis;
        [SerializeField] private float resetDuration = 0.1f;
        [SerializeField, Range(0f, 1f)] private float resetValue = 0f;
        [SerializeField] private bool smoothAnimation;
        [SerializeField] private float smoothDuration = 0.1f;
        [SerializeField] private string animationHandlerName;
        [SerializeField] private bool blends;
        [SerializeField] private AnimationCurve blendCurve;
        [SerializeField] private float blendDuration;

#if UNITY_EDITOR
        [SerializeField, HideInInspector] private bool flaggedForRemoval;
        [SerializeField, HideInInspector] private bool isSelectedForLinkedObjectChange;
#endif

        public MonoBehaviour LinkedObject => linkedObject;
        public string LinkedFieldName => linkedFieldName;
        public AnimationEffect AnimationEffect => animationEffect;
        public int Priority => priority;
        public AnimationCurve AnimationCurve => animationCurve;
        public float CurveMultiplier => curveMultiplier;
        public float CurveTimeMultiplier => curveTimeMultiplier;
        public AnimationType AnimationType => animationType;
        public AnimationAxis AnimationAxis => animationAxis;
        public float ResetDuration => resetDuration;
        public float ResetValue => resetValue;
        public bool SmoothAnimation => smoothAnimation;
        public float SmoothDuration => smoothDuration;
        public string AnimationHandlerName => animationHandlerName;
        public bool Blends => blends;
        public AnimationCurve BlendCurve => blendCurve;
        public float BlendDuration => blendDuration;

#if UNITY_EDITOR
        public bool FlaggedForRemoval => flaggedForRemoval;
#endif

        public int CompareTo(AnimationConfig other)
        {
            if (priority < other.priority)
            {
                return 1;
            }

            return -1;
        }

#if UNITY_EDITOR
        public void SetupLink(MonoBehaviour monoBehaviour, FieldInfo field)
        {
            linkedObject = monoBehaviour;
            linkedFieldName = field.Name;
            linkedTypeName = field.FieldType.Name;
        }

        public void OnValidate()
        {
            FieldInfo fieldInfo = Reflection.GetFieldWithName(linkedObject, linkedFieldName);

            Type underlyingType = Nullable.GetUnderlyingType(fieldInfo.FieldType);

            if (underlyingType != null)
            {
                linkedTypeName = underlyingType.Name;
                return;
            }

            linkedTypeName = fieldInfo.FieldType.Name;
        }
#endif
    }
}
