using System;
using System.Reflection;
using CardboardCore.Utilities;
using UnityEngine;

namespace Stranded.Characters.Animations
{
    public struct AnimationResult
    {
        public readonly AnimationEffect animationEffect;
        public readonly AnimationType animationType;
        public readonly AnimationAxis animationAxis;
        public readonly Vector3 vector;
        public readonly float blendStrength;
        public readonly bool isActive;

        public AnimationResult(AnimationEffect animationEffect, AnimationType animationType, AnimationAxis animationAxis, Vector3 vector, float blendStrength, bool isActive)
        {
            this.animationEffect = animationEffect;
            this.animationType = animationType;
            this.animationAxis = animationAxis;
            this.vector = vector;
            this.blendStrength = blendStrength;
            this.isActive = isActive;
        }
    }

    public class Animation : IComparable<Animation>
    {
        private FieldInfo linkedFieldInfo;
        private readonly MonoBehaviour linkedObject;
        private readonly string linkedFieldName;
        private readonly AnimationEffect animationEffect;
        private readonly int priority;
        private readonly AnimationCurve animationCurve;
        private readonly float curveMultiplier;
        private readonly float curveTimeMultiplier;
        private readonly AnimationType animationType;
        private readonly AnimationAxis animationAxis;
        private readonly float resetDuration;
        private readonly float resetValue;
        private readonly bool smoothAnimation;
        private readonly float smoothDuration;
        private readonly AnimationHandler animationHandler;
        private readonly bool blends;
        private readonly AnimationCurve blendCurve;
        private readonly float blendDuration;

        private float evaluationValue;
        private float smoothVelocity;
        private float resetVelocity;

        private float blendTargetEvalValue;
        private float blendEvalValue;
        private float blendVelocity;

        private Vector3 resultVector;
        private bool isResetting;
        private bool isActive;

        public AnimationType AnimationType => animationType;
        public AnimationAxis AnimationAxis => animationAxis;

        public Animation(AnimationConfig animationConfig, AnimationHandler animationHandler)
        {
            linkedFieldInfo = Reflection.GetFieldWithName(animationConfig.LinkedObject, animationConfig.LinkedFieldName);

            linkedObject = animationConfig.LinkedObject;
            linkedFieldName = animationConfig.LinkedFieldName;
            animationEffect = animationConfig.AnimationEffect;
            priority = animationConfig.Priority;
            animationCurve = animationConfig.AnimationCurve;
            curveMultiplier = animationConfig.CurveMultiplier;
            curveTimeMultiplier = animationConfig.CurveTimeMultiplier;
            animationType = animationConfig.AnimationType;
            animationAxis = animationConfig.AnimationAxis;
            resetDuration = animationConfig.ResetDuration;
            resetValue = animationConfig.ResetValue;
            smoothAnimation = animationConfig.SmoothAnimation;
            smoothDuration = animationConfig.SmoothDuration;
            blends = animationConfig.Blends;
            blendCurve = animationConfig.BlendCurve;
            blendDuration = animationConfig.BlendDuration;

            this.animationHandler = animationHandler;
            this.animationHandler.Init(this.linkedFieldInfo, this.linkedObject, SetCurveEvaluation, Reset, CancelReset, SetBlendEvalTarget, SetActive);

            // Active by default
            blendTargetEvalValue = 1f;
            isActive = true;
        }

        private float GetTargetValue()
        {
            float value = animationCurve.Evaluate(evaluationValue);
            return value * curveMultiplier;
        }

        private float CalculateBlendStrength()
        {
            if (blends)
            {
                if (Mathf.Abs(blendTargetEvalValue - blendEvalValue) <= 0.01f)
                {
                    return blendEvalValue;
                }

                blendEvalValue = Mathf.SmoothDamp(blendEvalValue, blendTargetEvalValue, ref blendVelocity, blendDuration);
                return blendCurve.Evaluate(blendEvalValue);
            }

            return 1f;
        }

        private Vector3 FilterVector(float targetValue, Vector3 vector)
        {
            switch (animationAxis)
            {
                case AnimationAxis.X:
                    vector.x = targetValue;
                    break;

                case AnimationAxis.Y:
                    vector.y = targetValue;
                    break;

                case AnimationAxis.Z:
                    vector.z = targetValue;
                    break;
            }

            return vector;
        }

        private void SetCurveEvaluation(float value)
        {
            // If resetting, we don't want to apply a new value
            if (isResetting)
            {
                return;
            }

            if (smoothAnimation)
            {
                evaluationValue = Mathf.SmoothDamp(evaluationValue, value, ref smoothVelocity, smoothDuration);
            }
            else
            {
                evaluationValue = value;
            }
        }

        private void SetActive(bool value)
        {
            blendEvalValue = 1f;
            isActive = value;
        }

        private void SetBlendEvalTarget(float value)
        {
            blendTargetEvalValue = value;
        }

        private void Reset()
        {
            isResetting = true;
        }

        private void CancelReset()
        {
            isResetting = false;
        }

        public AnimationResult Update(float deltaTime)
        {
            animationHandler.Update(deltaTime / curveTimeMultiplier);

            if (isResetting)
            {
                if (Mathf.Abs(resetValue - evaluationValue) <= 0.01f)
                {
                    isResetting = false;
                }
                else
                {
                    evaluationValue = Mathf.SmoothDamp(evaluationValue, resetValue, ref resetVelocity, resetDuration);
                }
            }

            Vector3 vector = FilterVector(GetTargetValue(), resultVector);
            bool active = isActive;

            float blendStrength = CalculateBlendStrength();

            return new AnimationResult(
                animationEffect,
                animationType,
                animationAxis,
                vector,
                blendStrength,
                active);
        }

        public int CompareTo(Animation other)
        {
            if (priority < other.priority)
            {
                return 1;
            }

            return -1;
        }
    }
}
