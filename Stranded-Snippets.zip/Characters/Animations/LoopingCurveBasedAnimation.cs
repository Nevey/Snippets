﻿using System;
using UnityEngine;

namespace Stranded.Characters.Animations
{
    [Serializable]
    public class LoopingCurveBasedAnimation : CurveBasedAnimation
    {
        [SerializeField, Tooltip("Relative to \"fullLoopDuration\"")] protected float myLoopDuration;
        
        private float currentDuration;

        public void Init(Transform body, float fullLoopDuration)
        {
            base.Init(body);
            myLoopDuration = fullLoopDuration * myLoopDuration;
        }

        public void Update(float deltaTime)
        {
            currentDuration += deltaTime;
            
            if (currentDuration > myLoopDuration)
            {
                currentDuration -= myLoopDuration;
            }

            float value = 1f / myLoopDuration * currentDuration;
            
            SetCurveEvaluationValue(value);
        }

        public override void Reset()
        {
            base.Reset();
            currentDuration = 0f;
        }

        public override void Validate()
        {
            base.Validate();
            
            myLoopDuration = Mathf.Clamp(myLoopDuration, 0f, 1f);
        }
    }
}