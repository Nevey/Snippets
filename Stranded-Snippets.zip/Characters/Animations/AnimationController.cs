using System;
using System.Collections.Generic;
using CardboardCore.Utilities;
using UnityEngine;

namespace Stranded.Characters.Animations
{
    [ExecuteInEditMode]
    public class AnimationController : MonoBehaviour
    {
        [SerializeField] private Transform target;
        [SerializeField] private AnimationConfig[] animationConfigs;

        private Animation[] animations;

        private Dictionary<AnimationEffect, List<AnimationResult>> animationPositionResults = new Dictionary<AnimationEffect, List<AnimationResult>>();
        private Dictionary<AnimationEffect, List<AnimationResult>> animationRotationResults = new Dictionary<AnimationEffect, List<AnimationResult>>();

        private void Awake()
        {
            if (!Application.isPlaying)
            {
                return;
            }

            animations = new Animation[animationConfigs.Length];

            for (int i = 0; i < animations.Length; i++)
            {
                animations[i] = new Animation(animationConfigs[i], GetAnimationHandler(animationConfigs[i].AnimationHandlerName));
            }

            for (int i = 0; i < Enum.GetValues(typeof(AnimationEffect)).Length; i++)
            {
                animationPositionResults[(AnimationEffect)i] = new List<AnimationResult>();
                animationRotationResults[(AnimationEffect)i] = new List<AnimationResult>();
            }

            Array.Sort(animations);
        }

        private void Update()
        {
#if UNITY_EDITOR
            if (Application.isPlaying)
            {
                UpdateRuntime();
            }
            else
            {
                UpdateEditorTime();
            }
#else
            UpdateRuntime();
#endif
        }

#if UNITY_EDITOR
        private void UpdateEditorTime()
        {
            if (animationConfigs == null)
            {
                return;
            }

            List<AnimationConfig> animationConfigList = new List<AnimationConfig>(animationConfigs);

            bool isSomethingRemoved = false;

            for (int i = animationConfigList.Count - 1; i >= 0; i--)
            {
                if (animationConfigList[i] == null)
                {
                    continue;
                }

                if (animationConfigList[i].FlaggedForRemoval)
                {
                    animationConfigList.RemoveAt(i);
                    isSomethingRemoved = true;
                }
            }

            if (isSomethingRemoved)
            {
                animationConfigs = animationConfigList.ToArray();
                UnityEditor.EditorUtility.SetDirty(this);
            }
        }
#endif

        private void UpdateRuntime()
        {
            for (int i = 0; i < animations.Length; i++)
            {
                AnimationResult animationResult = animations[i].Update(Time.deltaTime);

                if (!animationResult.isActive)
                {
                    continue;
                }

                switch (animations[i].AnimationType)
                {
                    case AnimationType.Position:
                        animationPositionResults[animationResult.animationEffect].Add(animationResult);
                        break;

                    case AnimationType.Rotation:
                        animationRotationResults[animationResult.animationEffect].Add(animationResult);
                        break;
                }
            }

            ApplyAnimationResults(animationPositionResults, AnimationType.Position);
            ApplyAnimationResults(animationRotationResults, AnimationType.Rotation);
        }

        private void ApplyAnimationResults(Dictionary<AnimationEffect, List<AnimationResult>> results, AnimationType animationType)
        {
            Vector3 targetVector = Vector3.zero;

            foreach (var item in results)
            {
                if (item.Value.Count == 0)
                {
                    continue;
                }

                Dictionary<AnimationAxis, int> amounts = new Dictionary<AnimationAxis, int>();

                for (int i = 0; i < item.Value.Count; i++)
                {
                    if (!amounts.ContainsKey(item.Value[i].animationAxis))
                    {
                        amounts[item.Value[i].animationAxis] = 0;
                    }

                    float blendStrength = item.Value[i].blendStrength;
                    Vector3 vector = item.Value[i].vector;

                    // The effect is only counted if the blendStrength is higher than 0, since 0 means it's not doing anything
                    if (blendStrength > 0f)
                    {
                        amounts[item.Value[i].animationAxis]++;
                    }

                    int amount = amounts[item.Value[i].animationAxis];
                    bool max = amount > 1 && i == amount - 1;

                    switch (item.Value[i].animationEffect)
                    {
                        // Note: The dictionary we're looping through has it's keys based on the enum we're checking below, so it's safe to assume there's no
                        // alienation. Every list we're looping through is always based on a single enum value
                        // Enums are sorted in this specific order
                        case AnimationEffect.Default:

                            switch (item.Value[i].animationAxis)
                            {
                                case AnimationAxis.X:

                                    targetVector.x += vector.x * blendStrength;

                                    if (max)
                                    {
                                        targetVector.x /= amount;
                                    }

                                    break;

                                case AnimationAxis.Y:

                                    targetVector.y += vector.y * blendStrength;

                                    if (max)
                                    {
                                        targetVector.y /= amount;
                                    }

                                    break;

                                case AnimationAxis.Z:

                                    targetVector.z += vector.z * blendStrength;

                                    if (max)
                                    {
                                        targetVector.z /= amount;
                                    }

                                    break;
                            }

                            break;

                        case AnimationEffect.Append:

                            switch (item.Value[i].animationAxis)
                            {
                                case AnimationAxis.X:
                                    targetVector.x += vector.x * blendStrength;
                                    break;

                                case AnimationAxis.Y:
                                    targetVector.y += vector.y * blendStrength;
                                    break;

                                case AnimationAxis.Z:
                                    targetVector.z += vector.z * blendStrength;
                                    break;
                            }

                            break;

                        case AnimationEffect.Override:

                            Vector3 baseVector = targetVector;
                            float restBlendStrength = 1f - blendStrength;

                            switch (item.Value[i].animationAxis)
                            {
                                case AnimationAxis.X:
                                    targetVector.x = vector.x * blendStrength + baseVector.x * restBlendStrength;
                                    break;

                                case AnimationAxis.Y:
                                    targetVector.y = vector.y * blendStrength + baseVector.y * restBlendStrength;
                                    break;

                                case AnimationAxis.Z:
                                    targetVector.z = vector.z * blendStrength + baseVector.z * restBlendStrength;
                                    break;
                            }

                            break;
                    }
                }

                item.Value.Clear();
            }

            switch (animationType)
            {
                case AnimationType.Position:
                    target.localPosition = targetVector;
                    break;

                case AnimationType.Rotation:
                    target.localEulerAngles = targetVector;
                    break;
            }
        }

        private AnimationHandler GetAnimationHandler(string name)
        {
            Type type = Reflection.GetType(typeof(AnimationHandler).Assembly, name);
            return (AnimationHandler)Activator.CreateInstance(type);
        }

#if UNITY_EDITOR
        public void SortConfigs()
        {
            Array.Sort(animationConfigs);
            UnityEditor.EditorUtility.SetDirty(this);
        }

        public void AddConfig(AnimationConfig animationConfig)
        {
            Array.Resize(ref animationConfigs, animationConfigs.Length + 1);
            animationConfigs[animationConfigs.Length - 1] = animationConfig;

            UnityEditor.EditorUtility.SetDirty(this);
        }

        private void OnValidate()
        {
            if (animationConfigs == null)
            {
                return;
            }

            for (int i = 0; i < animationConfigs.Length; i++)
            {
                animationConfigs[i].OnValidate();
            }

            UnityEditor.EditorUtility.SetDirty(this);
        }
#endif
    }
}
