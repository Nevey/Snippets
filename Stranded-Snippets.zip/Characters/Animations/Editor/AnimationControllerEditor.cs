using UnityEngine;
using UnityEditor;
using CardboardCore.Utilities;
using System.Reflection;
using System;
using System.Linq;

namespace Stranded.Characters.Animations
{
    public class AnimationLinkSelection
    {
        public MonoBehaviour mono;
        public FieldInfo field;
        public AnimationConfig animationConfig;
    }

    [CustomEditor(typeof(AnimationController))]
    public class AnimationControllerEditor : Editor
    {
        private AnimationController animationController;
        private MonoBehaviour[] MonoBehaviours => animationController.GetComponentsInChildren<MonoBehaviour>();
        private GenericMenu genericMenu;

        private SerializedProperty targetProperty;
        private SerializedProperty animationConfigsProperty;

        private void OnEnable()
        {
            animationController = (AnimationController)target;

            targetProperty = serializedObject.FindProperty("target");
            animationConfigsProperty = serializedObject.FindProperty("animationConfigs");
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            GUIStyle headerStyle = new GUIStyle();
            headerStyle.fontStyle = FontStyle.Bold;
            headerStyle.normal.textColor = Color.white;
            headerStyle.alignment = TextAnchor.MiddleCenter;
            headerStyle.fontSize = 16;

            EditorGUILayout.Space();

            EditorGUILayout.LabelField("Animation Tool", headerStyle);

            EditorGUILayout.Space();
            EditorGUILayout.Space();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Animation Target", GUILayout.Width(100));
            EditorGUILayout.PropertyField(targetProperty, GUIContent.none);
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();
            EditorGUILayout.Space();

            EditorGUILayout.BeginHorizontal();

            if (GUILayout.Button("Add Animation Config...", GUILayout.Height(30)))
            {
                ShowLinkedObjectSelection(null);
            }

            if (GUILayout.Button("Sort by Priority", GUILayout.Height(30)))
            {
                animationController.SortConfigs();
            }

            EditorGUILayout.EndHorizontal();

            for (int i = 0; i < animationConfigsProperty.arraySize; i++)
            {
                SerializedProperty animationConfigProperty = animationConfigsProperty.GetArrayElementAtIndex(i);
                EditorGUILayout.PropertyField(animationConfigProperty);

                SerializedProperty isSelectedForLinkedObjectChangeProperty = animationConfigProperty.FindPropertyRelative("isSelectedForLinkedObjectChange");

                if (isSelectedForLinkedObjectChangeProperty.boolValue)
                {
                    ShowLinkedObjectSelection(animationConfigProperty);
                    isSelectedForLinkedObjectChangeProperty.boolValue = false;
                }

                EditorGUILayout.Separator();
            }

            serializedObject.ApplyModifiedProperties();
        }

        private void ShowLinkedObjectSelection(SerializedProperty property)
        {
            genericMenu = new GenericMenu();

            for (int i = 0; i < MonoBehaviours.Length; i++)
            {
                FieldInfo[] fields = Reflection.GetFieldsWithAttribute<AnimationLinkAttribute>(MonoBehaviours[i].GetType());

                for (int k = 0; k < fields.Length; k++)
                {
                    AddMenuItem(genericMenu, MonoBehaviours, fields, i, k, property);
                }
            }

            genericMenu.ShowAsContext();
        }

        private void AddMenuItem(GenericMenu genericMenu, MonoBehaviour[] monoBehaviours, FieldInfo[] fields, int monoIndex, int fieldIndex, SerializedProperty property)
        {
            MonoBehaviour monoBehaviour = monoBehaviours[monoIndex];
            FieldInfo field = fields[fieldIndex];

            AnimationConfig animationConfig = null;

            if (property != null)
            {
                FieldInfo animationConfigsFieldInfo = Reflection.GetFieldWithName(animationController, "animationConfigs");
                animationConfig = GetActualObjectForSerializedProperty<AnimationConfig>(animationConfigsFieldInfo, property);
            }

            AnimationLinkSelection selection = new AnimationLinkSelection
            {
                mono = monoBehaviour,
                field = field,
                animationConfig = animationConfig
            };

            genericMenu.AddItem(new GUIContent($"{monoBehaviour.GetType().Name}/{field.Name}"), false, HandleGenericMenuSelection, selection);
        }

        private void HandleGenericMenuSelection(object selectionObject)
        {
            AnimationLinkSelection selection = (AnimationLinkSelection)selectionObject;

            AnimationConfig animationConfig = selection.animationConfig ?? new AnimationConfig();
            animationConfig.SetupLink(selection.mono, selection.field);

            // We didn't create a new animation config, early out to not add existing animation config to array 
            if (selection.animationConfig != null)
            {
                EditorUtility.SetDirty(animationController);
                serializedObject.Update();
                serializedObject.ApplyModifiedProperties();

                return;
            }

            serializedObject.Update();
            animationController.AddConfig(animationConfig);
            serializedObject.ApplyModifiedProperties();
        }

        public static T GetActualObjectForSerializedProperty<T>(FieldInfo fieldInfo, SerializedProperty property) where T : class
        {
            object obj = fieldInfo.GetValue(property.serializedObject.targetObject);

            if (obj == null)
            {
                return null;
            }

            T actualObject = null;

            if (obj.GetType().IsArray)
            {
                var index = Convert.ToInt32(new string(property.propertyPath.Where(c => char.IsDigit(c)).ToArray()));
                actualObject = ((T[])obj)[index];
            }
            else
            {
                actualObject = obj as T;
            }

            return actualObject;
        }
    }
}
