using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace Stranded.Characters.Animations
{
    [CustomPropertyDrawer(typeof(AnimationConfig))]
    public class AnimationConfigDrawer : PropertyDrawer
    {
        private string[] GetAnimationHandlerNames(bool isFilterEnabled = false, string filteredTypeName = "")
        {
            Type type = typeof(AnimationHandler);
            Type[] types = type.Assembly.GetTypes().Where(t => type.IsAssignableFrom(t) && !t.IsAbstract).ToArray();

            List<string> names = new List<string>();
            for (int i = 0; i < types.Length; i++)
            {
                if (!isFilterEnabled
                    || types[i].BaseType.GenericTypeArguments[0].Name == filteredTypeName)
                {
                    names.Add(types[i].Name);
                }
            }

            return names.ToArray();
        }

        private int GetAnimationHandlerIndex(string animationHandlerName, bool isFilterEnabled = false, string filteredTypeName = "")
        {
            string[] names = GetAnimationHandlerNames(isFilterEnabled, filteredTypeName);

            for (int i = 0; i < names.Length; i++)
            {
                if (names[i].Equals(animationHandlerName))
                {
                    return i;
                }
            }

            return -1;
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            GUIStyle headerStyle = new GUIStyle();
            headerStyle.normal.textColor = Color.white;
            headerStyle.fontStyle = FontStyle.Bold;
            headerStyle.richText = true;

            GUIStyle richTextStyle = new GUIStyle();
            richTextStyle.richText = true;
            richTextStyle.normal.textColor = new Color(0.7254901960784314f, 0.7254901960784314f, 0.7254901960784314f);

            SerializedProperty nameProperty = property.FindPropertyRelative("animationName");
            SerializedProperty isFoldedOutProperty = property.FindPropertyRelative("isFoldedOut");

            label.text = nameProperty.stringValue.Equals("") ? label.text.Replace("Element", "Animation") : nameProperty.stringValue;

            isFoldedOutProperty.boolValue = EditorGUILayout.BeginFoldoutHeaderGroup(isFoldedOutProperty.boolValue, label);

            if (isFoldedOutProperty.boolValue)
            {
                SerializedProperty linkedObjectProperty = property.FindPropertyRelative("linkedObject");
                SerializedProperty linkedFieldProperty = property.FindPropertyRelative("linkedFieldName");
                SerializedProperty filterBasedOnFieldProperty = property.FindPropertyRelative("filterBasedOnField");
                SerializedProperty selectedAnimationHandlerIndexProperty = property.FindPropertyRelative("selectedAnimationHandlerIndex");
                SerializedProperty smoothAnimationProperty = property.FindPropertyRelative("smoothAnimation");
                SerializedProperty animationCurveProperty = property.FindPropertyRelative("animationCurve");

                EditorGUILayout.BeginVertical("box");

                EditorGUILayout.BeginVertical("box");
                EditorGUILayout.LabelField("Name", headerStyle);
                nameProperty.stringValue = EditorGUILayout.TextField(nameProperty.stringValue);
                EditorGUILayout.EndVertical();

                EditorGUILayout.Space();

                EditorGUILayout.BeginVertical("box");
                EditorGUILayout.LabelField("Linked Field", headerStyle);
                EditorGUILayout.LabelField($"<b><i>{linkedFieldProperty.stringValue}</i></b> in {linkedObjectProperty.objectReferenceValue}", richTextStyle);
                if (GUILayout.Button("Change", GUILayout.Width(100)))
                {
                    property.FindPropertyRelative("isSelectedForLinkedObjectChange").boolValue = true;
                }
                EditorGUILayout.EndVertical();

                EditorGUILayout.Space();


                EditorGUILayout.BeginVertical("box");
                EditorGUILayout.LabelField("Logic/Code Handler", headerStyle);

                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField($"Filter Based On <b><i>({linkedFieldProperty.stringValue})</i></b>", richTextStyle);
                EditorGUILayout.PropertyField(filterBasedOnFieldProperty, GUIContent.none);
                EditorGUILayout.EndHorizontal();

                string linkedTypeName = property.FindPropertyRelative("linkedTypeName").stringValue;
                string[] animationHandlerNames = GetAnimationHandlerNames(filterBasedOnFieldProperty.boolValue, linkedTypeName);

                if (animationHandlerNames != null && animationHandlerNames.Length > 0)
                {
                    SerializedProperty animationHandlerNameProperty = property.FindPropertyRelative("animationHandlerName");

                    if (String.IsNullOrEmpty(animationHandlerNameProperty.stringValue))
                    {
                        selectedAnimationHandlerIndexProperty.intValue = EditorGUILayout.Popup(selectedAnimationHandlerIndexProperty.intValue, animationHandlerNames);
                    }
                    else
                    {
                        selectedAnimationHandlerIndexProperty.intValue = EditorGUILayout.Popup(GetAnimationHandlerIndex(animationHandlerNameProperty.stringValue, filterBasedOnFieldProperty.boolValue, linkedTypeName), animationHandlerNames);
                    }

                    // In case stuff is removed
                    if (animationHandlerNames.Length < selectedAnimationHandlerIndexProperty.intValue)
                    {
                        selectedAnimationHandlerIndexProperty.intValue = animationHandlerNames.Length - 1;
                    }

                    if (selectedAnimationHandlerIndexProperty.intValue < 0)
                    {
                        selectedAnimationHandlerIndexProperty.intValue = 0;
                    }

                    animationHandlerNameProperty.stringValue = animationHandlerNames[selectedAnimationHandlerIndexProperty.intValue];
                }
                else
                {
                    EditorGUILayout.LabelField("No AnimationHandlers are available! This animation will never work...");
                }
                EditorGUILayout.EndVertical();

                EditorGUILayout.Space();

                EditorGUILayout.BeginVertical("box");
                EditorGUILayout.LabelField("Curve Settings", headerStyle);
                animationCurveProperty.animationCurveValue = EditorGUILayout.CurveField("Animation Curve", animationCurveProperty.animationCurveValue, Color.cyan, new Rect(new Vector2(0, -1), new Vector2(1, 2)));
                EditorGUILayout.PropertyField(property.FindPropertyRelative("curveMultiplier"));
                EditorGUILayout.PropertyField(property.FindPropertyRelative("curveTimeMultiplier"));
                EditorGUILayout.EndVertical();

                EditorGUILayout.Space();

                EditorGUILayout.BeginVertical("box");
                EditorGUILayout.LabelField("Blending", headerStyle);
                SerializedProperty blendsProperty = property.FindPropertyRelative("blends");
                EditorGUILayout.PropertyField(blendsProperty);

                if (blendsProperty.boolValue)
                {
                    SerializedProperty blendCurveProperty = property.FindPropertyRelative("blendCurve");
                    blendCurveProperty.animationCurveValue = EditorGUILayout.CurveField("Blending Curve", blendCurveProperty.animationCurveValue, Color.cyan, new Rect(Vector2.zero, Vector2.one));
                    EditorGUILayout.PropertyField(property.FindPropertyRelative("blendDuration"));
                }

                EditorGUILayout.EndVertical();

                EditorGUILayout.Space();

                EditorGUILayout.BeginVertical("box");
                EditorGUILayout.LabelField("Smoothing", headerStyle);
                EditorGUILayout.PropertyField(smoothAnimationProperty);
                if (smoothAnimationProperty.boolValue)
                {
                    EditorGUILayout.PropertyField(property.FindPropertyRelative("smoothDuration"));
                }
                EditorGUILayout.EndVertical();

                EditorGUILayout.Space();

                EditorGUILayout.BeginVertical("box");
                EditorGUILayout.LabelField("Animation Effect Settings", headerStyle);
                EditorGUILayout.PropertyField(property.FindPropertyRelative("animationEffect"), new GUIContent("Animation Effect", "The way this animation will affect the target"));
                EditorGUILayout.PropertyField(property.FindPropertyRelative("priority"), new GUIContent("Priority", "Mostly applicable for Override animations"));
                EditorGUILayout.EndVertical();

                EditorGUILayout.Space();

                EditorGUILayout.BeginVertical("box");
                EditorGUILayout.LabelField("Animation Type Settings", headerStyle);
                EditorGUILayout.PropertyField(property.FindPropertyRelative("animationType"));
                EditorGUILayout.PropertyField(property.FindPropertyRelative("animationAxis"));
                EditorGUILayout.EndVertical();

                EditorGUILayout.Space();

                EditorGUILayout.BeginVertical("box");
                EditorGUILayout.LabelField("Resetting", headerStyle);
                EditorGUILayout.PropertyField(property.FindPropertyRelative("resetDuration"));
                EditorGUILayout.PropertyField(property.FindPropertyRelative("resetValue"), new GUIContent("Reset Value", "The \"idle\" value, when the animation is reset"));
                EditorGUILayout.EndVertical();

                EditorGUILayout.Space();
                EditorGUILayout.Space();

                if (GUILayout.Button("Remove"))
                {
                    property.FindPropertyRelative("flaggedForRemoval").boolValue = true;
                }
                EditorGUILayout.EndVertical();
            }

            EditorGUILayout.EndFoldoutHeaderGroup();
        }
    }
}
