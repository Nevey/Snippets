using Stranded.Characters.Combat.Attacking;

public class AttackAnimationHandler : AnimationInputHandler<AttackState>
{
    protected override void OnInitialize()
    {

    }

    protected override void OnUpdate(float normalizedDeltaTime, AttackState input)
    {
        switch (input)
        {
            case AttackState.None:
            case AttackState.Cooldown:
                Reset();
                SetBlendEvalTarget(0f);
                return;

            case AttackState.InitialSweep:
            case AttackState.SweepRightToLeft:
                SetCurveEvaluation(1f);
                break;

            case AttackState.SweepLeftToRight:
                SetCurveEvaluation(0f);
                break;
        }

        CancelReset();
        SetBlendEvalTarget(1f);
    }
}
