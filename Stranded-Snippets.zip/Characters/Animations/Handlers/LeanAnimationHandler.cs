using Stranded.Characters.Movement;
using UnityEngine;

public class LeanAnimationHandler : AnimationInputHandler<Vector2>
{
    private Rigidbody rigidbody;
    private CharacterMovement characterMovement;

    protected override void OnInitialize()
    {
        // TODO: Research adding support for multiple inputs, instead of getting components like this!
        rigidbody = linkedObject.GetComponent<Rigidbody>();
        characterMovement = linkedObject.GetComponent<CharacterMovement>();
    }

    protected override void OnUpdate(float normalizedDeltaTime, Vector2 input)
    {
        float targetSpeed = input == Vector2.zero ? 0f : characterMovement.MovementData.WalkMaxMovementSpeed;
        float speedOffset = targetSpeed - rigidbody.velocity.magnitude;

        float relativeOffset;

        if (targetSpeed < 0.1f)
        {
            relativeOffset = -(0.5f / characterMovement.MovementData.WalkMaxMovementSpeed * rigidbody.velocity.magnitude);
        }
        else
        {
            relativeOffset = 0.5f / targetSpeed * speedOffset;
        }

        float evaluationValue = 0.5f + relativeOffset;

        SetCurveEvaluation(evaluationValue);
    }
}
