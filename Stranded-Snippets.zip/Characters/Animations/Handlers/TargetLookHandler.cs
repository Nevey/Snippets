using Stranded.Characters.Combat.Targeting;
using UnityEngine;

public class TargetLookHandler : AnimationInputHandler<Targetable>
{
    protected override void OnInitialize()
    {

    }

    protected override void OnUpdate(float normalizedDeltaTime, Targetable input)
    {
        if (input == null)
        {
            SetBlendEvalTarget(0f);
            return;
        }

        // Note that we're rotating the main player via movement logic
        // And we're rotating the underlying body based on it's forward transform
        Transform playerTransform = linkedObject.transform.parent;

        if (!playerTransform.name.Contains("Player"))
        {
            Log.Error("Are you sure you're trying to apply rotation to a player?");
        }

        Vector3 targetDirection = playerTransform.position - input.transform.position;
        targetDirection.y = 0f;

        float signedAngle = Vector3.SignedAngle(playerTransform.forward, targetDirection.normalized, Vector3.up);

        // Create curve value between -1 and 1
        float curveValue = signedAngle / 180f;

        // Create curve value between 0 and 1
        curveValue += 1f;
        curveValue /= 2f;

        SetCurveEvaluation(curveValue);
        SetBlendEvalTarget(1f);
    }
}
