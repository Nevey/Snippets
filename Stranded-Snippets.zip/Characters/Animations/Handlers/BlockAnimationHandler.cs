using Stranded.Characters.Combat.Defending;

public class BlockAnimationHandler : AnimationInputHandler<BlockState>
{
    protected override void OnInitialize()
    {

    }

    protected override void OnUpdate(float normalizedDeltaTime, BlockState input)
    {
        float evalValue = input == BlockState.Block ? 1f : 0f;

        SetBlendEvalTarget(evalValue);
        SetCurveEvaluation(evalValue);
    }
}
