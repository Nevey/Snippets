using System;
using System.Reflection;
using UnityEngine;

public abstract class AnimationHandler
{
    protected FieldInfo linkedFieldInfo;
    protected MonoBehaviour linkedObject;
    protected Action<float> SetCurveEvaluation;
    protected Action Reset;
    protected Action CancelReset;
    protected Action<float> SetBlendEvalTarget;
    protected Action<bool> SetActive;

    public Type linkedFieldType => linkedFieldInfo.GetType();

    protected abstract void OnInitialize();
    protected abstract void OnUpdate(float normalizedDeltaTime);

    public void Init(FieldInfo linkedFieldInfo, MonoBehaviour linkedObject, Action<float> SetCurveEvaluation, Action Reset, Action CancelReset, Action<float> SetBlendEvalTarget, Action<bool> SetActive)
    {
        this.linkedFieldInfo = linkedFieldInfo;
        this.linkedObject = linkedObject;
        this.SetCurveEvaluation = SetCurveEvaluation;
        this.Reset = Reset;
        this.CancelReset = CancelReset;
        this.SetBlendEvalTarget = SetBlendEvalTarget;
        this.SetActive = SetActive;

        OnInitialize();
    }

    public void Update(float normalizedDeltaTime)
    {
        OnUpdate(normalizedDeltaTime);
    }
}

public abstract class AnimationInputHandler<T> : AnimationHandler
{
    protected abstract void OnUpdate(float normalizedDeltaTime, T input);

    protected override void OnUpdate(float normalizedDeltaTime)
    {
        T input = default(T);

        if (linkedFieldInfo != null)
        {
            input = (T)linkedFieldInfo.GetValue(linkedObject);
        }

        OnUpdate(normalizedDeltaTime, input);
    }
}
