using UnityEngine;

public class LoopableAnimationHandler : AnimationInputHandler<Vector2>
{
    private const float maxDuration = 1f;

    private float currentDuration;

    protected override void OnInitialize()
    {

    }

    protected override void OnUpdate(float normalizedDeltaTime, Vector2 input)
    {
        if (input == Vector2.zero)
        {
            Reset();
            currentDuration = 0f;

            return;
        }

        currentDuration += normalizedDeltaTime;

        if (currentDuration > maxDuration)
        {
            currentDuration -= maxDuration;
        }

        float value = maxDuration * currentDuration;

        SetCurveEvaluation(value);
    }
}
