using Stranded.Characters.Actions;

public class FeedActionHandler : AnimationInputHandler<CharacterAction?>
{
    private float currentDuration;

    protected override void OnInitialize()
    {

    }

    protected override void OnUpdate(float normalizedDeltaTime, CharacterAction? input)
    {
        if (input == null)
        {
            SetBlendEvalTarget(0f);
            return;
        }

        if (input.Value.CharacterActionType != CharacterActionType.Feed)
        {
            SetBlendEvalTarget(0f);
            return;
        }

        SetBlendEvalTarget(1f);

        currentDuration += normalizedDeltaTime;

        if (currentDuration > 1f)
        {
            currentDuration -= 1f;
        }

        float value = currentDuration;

        SetCurveEvaluation(value);
    }
}
