﻿using System.Collections.Generic;
using Stranded.Characters.AI;
using Stranded.PointsOfInterest;
using Stranded.Stats;
using UnityEngine;

namespace Stranded.Characters.Needs
{
    [RequireComponent(typeof(AISurroundingsAwareness))]
    [RequireComponent(typeof(StatsController))]
    public class CharacterNeedController : MonoBehaviour
    {
        [SerializeField] private CharacterNeedConfigs characterNeedConfigs;

        private readonly Dictionary<CharacterNeedType, CharacterNeed> runtimeCharacterNeeds =
            new Dictionary<CharacterNeedType, CharacterNeed>();

        private AISurroundingsAwareness aiSurroundingsAwareness;
        private StatsController statsController;

        private void Awake()
        {
            aiSurroundingsAwareness = GetComponent<AISurroundingsAwareness>();

            statsController = GetComponent<StatsController>();
            statsController.NeedyEvent += OnStatNeedy;
            statsController.NeedSatisfiedEvent += OnStatNeedSatisfied;

            // TODO: Load runtime data if exists (after saving)
        }

        private void OnDestroy()
        {
            statsController.NeedyEvent -= OnStatNeedy;
            statsController.NeedSatisfiedEvent -= OnStatNeedSatisfied;
        }

        private void OnStatNeedSatisfied(CharacterNeedType characterNeedType)
        {
            // Keep this need so we can keep satisfying it, first world problems...
            // if (runtimeCharacterNeeds.Count == 1)
            // {
            //     return;
            // }

            RemoveNeed(characterNeedType);
        }

        private void OnStatNeedy(CharacterNeedType characterNeedType)
        {
            AddNeed(characterNeedType);
        }

        private void AddNeed(CharacterNeedType characterNeedType)
        {
            if (runtimeCharacterNeeds.ContainsKey(characterNeedType))
            {
                // TODO: Check if we want to increase existing need value instead
                return;
            }

            CharacterNeedConfig config = characterNeedConfigs.GetNeedConfig(characterNeedType);

            if (config == null)
            {
                throw Log.Exception($"No CharacterNeedConfig available for CharacterNeedType {characterNeedType} for {gameObject.name}!");
            }

            CharacterNeed characterNeed = new CharacterNeed
            {
                characterNeedType = config.CharacterNeedType,
                pointOfInterestTypes = config.PointOfInterestTypes,
                resourceTypes = config.ResourceTypes,
            };

            runtimeCharacterNeeds[characterNeedType] = characterNeed;
        }

        private void RemoveNeed(CharacterNeedType characterNeedType)
        {
            if (!runtimeCharacterNeeds.ContainsKey(characterNeedType))
            {
                return;
            }

            runtimeCharacterNeeds.Remove(characterNeedType);
        }

        public CharacterNeed GetNeed(CharacterNeedType characterNeedType)
        {
            return runtimeCharacterNeeds.TryGetValue(characterNeedType, out CharacterNeed characterNeed)
                ? characterNeed
                : null;
        }

        public CharacterNeed[] GetNeeds(params CharacterNeedType[] characterNeedTypes)
        {
            List<CharacterNeed> needs = new List<CharacterNeed>();

            for (int i = 0; i < characterNeedTypes.Length; i++)
            {
                if (runtimeCharacterNeeds.TryGetValue(characterNeedTypes[i], out CharacterNeed characterNeed))
                {
                    needs.Add(characterNeed);
                }
            }

            return needs.ToArray();
        }

        public bool IsNeedBasedPOIInRange(CharacterNeedType characterNeedType)
        {
            CharacterNeed characterNeed = GetNeed(characterNeedType);

            if (characterNeed == null)
            {
                return false;
            }

            for (int i = 0; i < characterNeed.pointOfInterestTypes.Length; i++)
            {
                PointOfInterestType pointOfInterestType = characterNeed.pointOfInterestTypes[i];

                if (aiSurroundingsAwareness.IsPOIInRange(pointOfInterestType, out PointOfInterest pointOfInterest))
                {
                    return true;
                }
            }

            return false;
        }

        public bool IsNeedBasedPOIInRange(CharacterNeedType characterNeedType, out PointOfInterest POI)
        {
            CharacterNeed characterNeed = GetNeed(characterNeedType);

            POI = null;

            if (characterNeed == null)
            {
                return false;
            }

            for (int i = 0; i < characterNeed.pointOfInterestTypes.Length; i++)
            {
                PointOfInterestType pointOfInterestType = characterNeed.pointOfInterestTypes[i];

                if (aiSurroundingsAwareness.IsPOIInRange(pointOfInterestType, out PointOfInterest pointOfInterest))
                {
                    POI = pointOfInterest;
                    return true;
                }
            }

            return false;
        }
    }
}
