﻿using Stranded.PointsOfInterest;
using Stranded.ResourcesSystem;

namespace Stranded.Characters.Needs
{
    public class CharacterNeed
    {
        public CharacterNeedType characterNeedType;
        public PointOfInterestType[] pointOfInterestTypes;
        public ResourceType[] resourceTypes;
    }
}