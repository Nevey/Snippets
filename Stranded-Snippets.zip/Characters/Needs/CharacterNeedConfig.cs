using System;
using Stranded.PointsOfInterest;
using Stranded.ResourcesSystem;
using UnityEngine;

namespace Stranded.Characters.Needs
{
    [Serializable]
    public class CharacterNeedConfig
    {
        // The type of need this represents
        [SerializeField] private CharacterNeedType characterNeedType;
        
        // The point of interest(s) this need could be fulfilled by
        [SerializeField] private PointOfInterestType[] pointOfInterestTypes;

        // The types of resources this need can fulfill
        [SerializeField] private ResourceType[] resourceTypes;

        public CharacterNeedType CharacterNeedType => characterNeedType;
        public PointOfInterestType[] PointOfInterestTypes => pointOfInterestTypes;
        public ResourceType[] ResourceTypes => resourceTypes;
    }
}
