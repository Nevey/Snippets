﻿using UnityEngine;

namespace Stranded.Characters.Needs
{
    [CreateAssetMenu(fileName = "CharacterNeedConfigs", menuName = "Stranded/CharacterNeedConfigs", order = 0)]
    public class CharacterNeedConfigs : ScriptableObject
    {
        [SerializeField] private CharacterNeedConfig[] needConfigs;

        public CharacterNeedConfig GetNeedConfig(CharacterNeedType characterNeedType)
        {
            for (int i = 0; i < needConfigs.Length; i++)
            {
                if (needConfigs[i].CharacterNeedType == characterNeedType)
                {
                    return needConfigs[i];
                }
            }

            return null;
        }
    }
}