namespace Stranded.Characters.Needs
{
    public enum CharacterNeedType
    {
        Food,
        StayWithHerd,
        BeAlone,
        Poop,
        Kill,
        Sleep,
        None,
        HigherTemperature,
        LowerTemperature,
        Relax
    }
}
