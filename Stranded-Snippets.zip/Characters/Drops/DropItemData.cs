using System;
using UnityEngine;

namespace Stranded.Characters.Drops
{
    [Serializable]
    public class DropItemData
    {
        // Editor Only
        [SerializeField] private bool queuedForRemoval;

        [SerializeField] private string prefabName;
        [SerializeField] private int amount = 3;

        public string PrefabName => prefabName;
        public int Amount => amount;
    }
}
