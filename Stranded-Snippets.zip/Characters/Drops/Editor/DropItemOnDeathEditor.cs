using UnityEngine;
using UnityEditor;

namespace Stranded.Characters.Drops
{
    [CustomEditor(typeof(DropItemOnDeath))]
    public class DropItemOnDeathEditor : Editor
    {
        private SerializedProperty dropItemDataArrayProperty;

        private void OnEnable()
        {
            dropItemDataArrayProperty = serializedObject.FindProperty("dropItemDataArray");
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            GUIStyle headerStyle = new GUIStyle();
            headerStyle.normal.textColor = Color.white;
            headerStyle.fontStyle = FontStyle.Bold;
            headerStyle.fontSize = 16;
            headerStyle.alignment = TextAnchor.MiddleCenter;

            EditorGUILayout.LabelField("Items to drop on Death", headerStyle);

            EditorGUILayout.Space();

            if (GUILayout.Button("Add Item to Drop...", GUILayout.Height(50)))
            {
                dropItemDataArrayProperty.InsertArrayElementAtIndex(dropItemDataArrayProperty.arraySize);
            }

            EditorGUILayout.Space();

            for (int i = dropItemDataArrayProperty.arraySize - 1; i >= 0; i--)
            {
                SerializedProperty dropItemDataProperty = dropItemDataArrayProperty.GetArrayElementAtIndex(i);

                SerializedProperty queuedForRemoval = dropItemDataProperty.FindPropertyRelative("queuedForRemoval");
                if (queuedForRemoval.boolValue)
                {
                    dropItemDataArrayProperty.DeleteArrayElementAtIndex(i);
                    continue;
                }

                EditorGUILayout.PropertyField(dropItemDataProperty);
            }

            serializedObject.ApplyModifiedProperties();
        }
    }
}
