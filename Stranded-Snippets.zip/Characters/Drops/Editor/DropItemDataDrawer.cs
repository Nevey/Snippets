using UnityEngine;
using UnityEditor;
using CardboardCore.DI;
using Stranded.Items;
using System;

namespace Stranded.Characters.Drops
{
    [CustomPropertyDrawer(typeof(DropItemData))]
    public class DropItemDataDrawer : PropertyDrawer
    {
        [Inject] private ItemsManager itemsManager;

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            if (itemsManager == null)
            {
                Injector.Inject(this);
            }

            if (itemsManager.PoolEntries != null && itemsManager.PoolEntries.Length > 0)
            {
                SerializedProperty prefabNameProperty = property.FindPropertyRelative("prefabName");

                EditorGUILayout.BeginHorizontal("box");

                EditorGUILayout.LabelField("Item World-Instance Name", GUILayout.Width(250));

                EditorGUILayout.PropertyField(property.FindPropertyRelative("amount"), GUIContent.none, GUILayout.Width(30));

                if (GUILayout.Button(string.Equals(prefabNameProperty.stringValue, "") ? "NONE SELECTED..." : prefabNameProperty.stringValue))
                {
                    GenericMenu genericMenu = new GenericMenu();

                    for (int i = 0; i < itemsManager.PoolEntries.Length; i++)
                    {
                        genericMenu.AddItem(new GUIContent(itemsManager.PoolEntries[i].Prefab.name), false, OnSelect, new Tuple<string, SerializedProperty>(itemsManager.PoolEntries[i].Prefab.name, property));
                    }

                    genericMenu.ShowAsContext();
                }

                if (GUILayout.Button("-", GUILayout.Width(25)))
                {
                    property.FindPropertyRelative("queuedForRemoval").boolValue = true;
                }

                EditorGUILayout.EndHorizontal();
            }
        }

        private void OnSelect(object @object)
        {
            Tuple<string, SerializedProperty> tuple = (Tuple<string, SerializedProperty>)@object;

            string prefabName = tuple.Item1;

            tuple.Item2.FindPropertyRelative("prefabName").stringValue = prefabName;
            tuple.Item2.serializedObject.ApplyModifiedProperties();
        }
    }
}
