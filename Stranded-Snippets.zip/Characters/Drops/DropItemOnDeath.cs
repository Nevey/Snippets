using CardboardCore.DI;
using Stranded.Characters.Combat.Attacking;
using Stranded.Items;
using UnityEngine;

namespace Stranded.Characters.Drops
{
    [RequireComponent(typeof(Damageable))]
    public class DropItemOnDeath : CardboardCoreBehaviour
    {
        [SerializeField] private DropItemData[] dropItemDataArray;

        [Inject] private ItemsManager itemsManager;

        private Damageable damageable;

        protected override void Awake()
        {
            base.Awake();

            damageable = GetComponent<Damageable>();
            damageable.KilledEvent += OnKilled;
        }

        protected override void OnDestroy()
        {
            damageable.KilledEvent -= OnKilled;

            base.OnDestroy();
        }

        private void OnKilled()
        {
            for (int i = 0; i < dropItemDataArray.Length; i++)
            {
                for (int k = 0; k < dropItemDataArray[i].Amount; k++)
                {
                    ItemWorldInstance itemWorldInstance = itemsManager.CreateItem(dropItemDataArray[i].PrefabName, transform.position);
                    itemWorldInstance.DoJump();
                }
            }
        }
    }
}
