﻿using System;
using System.Collections;
using System.Collections.Generic;
using Stranded.Characters.Animations;
using UnityEditor;
using UnityEngine;

namespace Stranded.Characters.Actions
{
    [Serializable]
    public struct CharacterAction
    {
        [SerializeField] private CharacterActionType characterActionType;
        [SerializeField] private float duration;
        [SerializeField] private bool ignoreDuration;

        public CharacterActionType CharacterActionType => characterActionType;
        public float Duration => duration;
        public bool IgnoreDuration => ignoreDuration;
    }

    public class CharacterActionController : MonoBehaviour
    {
        [SerializeField] private CharacterAction[] characterActions;

        private readonly Dictionary<CharacterActionType, CharacterAction> actionDict =
            new Dictionary<CharacterActionType, CharacterAction>();

        [AnimationLink] private CharacterAction? currentAction;
        private float currentActionDuration;
        private Coroutine actionDurationRoutine;
        private Action characterActionFinishedCallback;

        public CharacterActionType CharacterActionType => currentAction?.CharacterActionType ?? CharacterActionType.None;

        public event Action<CharacterActionType> CharacterActionStartedEvent;
        public event Action<CharacterActionType> CharacterActionFinishedEvent;

        private void Awake()
        {
            for (int i = 0; i < characterActions.Length; i++)
            {
                actionDict[characterActions[i].CharacterActionType] = characterActions[i];
            }
        }

        private void OnDrawGizmos()
        {
            if (currentAction == null)
            {
                return;
            }

#if UNITY_EDITOR
            Vector3 labelPosition = transform.position;
            labelPosition.y -= 1f;
            Handles.Label(labelPosition, $"Action: {currentAction.Value.CharacterActionType}");
#endif
        }

        private IEnumerator ActionDurationEnumerator()
        {
            if (currentAction == null)
            {
                throw Log.Exception($"{name} is trying to start an action duration check while no CharacterAction was assigned!");
            }

            const float interval = 0.5f;

            while (currentActionDuration < currentAction.Value.Duration)
            {
                yield return new WaitForSeconds(interval);

                currentActionDuration += interval;
            }

            FinishAction();
        }

        private void FinishAction()
        {
            // Should always be able to safely assume that "currentAction" will never be null when calling this method
            CharacterActionType characterActionType = currentAction.Value.CharacterActionType;

            currentAction = null;
            currentActionDuration = 0f;

            // To support chaining
            Action callback = characterActionFinishedCallback;
            characterActionFinishedCallback = null;
            callback?.Invoke();

            CharacterActionFinishedEvent?.Invoke(characterActionType);
        }

        public CharacterAction GetAction(CharacterActionType characterActionType)
        {
            if (!actionDict.TryGetValue(characterActionType, out CharacterAction characterAction))
            {
                throw Log.Exception($"{name} has no CharacterAction of Type <b>{characterActionType}</b> defined!");
            }

            return characterAction;
        }

        public CharacterAction StartAction(CharacterActionType characterActionType, Action callback = null)
        {
            if (currentAction != null)
            {
                CancelAction(false);
            }

            if (!actionDict.TryGetValue(characterActionType, out CharacterAction characterAction))
            {
                throw Log.Exception($"{name} has no CharacterAction of Type <b>{characterActionType}</b> defined!");
            }

            characterActionFinishedCallback = callback;

            currentAction = characterAction;

            if (!characterAction.IgnoreDuration)
            {
                actionDurationRoutine = StartCoroutine(ActionDurationEnumerator());
            }

            CharacterActionStartedEvent?.Invoke(characterActionType);

            return characterAction;
        }

        public void CancelAction(bool handleLikeFinished = true)
        {
            currentActionDuration = 0f;

            if (currentAction == null)
            {
                return;
            }

            if (actionDurationRoutine != null)
            {
                StopCoroutine(actionDurationRoutine);
                actionDurationRoutine = null;
            }

            if (handleLikeFinished)
            {
                FinishAction();
            }
            else
            {
                currentAction = null;
            }

            characterActionFinishedCallback = null;
        }
    }
}
