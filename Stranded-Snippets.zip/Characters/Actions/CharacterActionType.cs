﻿namespace Stranded.Characters.Actions
{
    public enum CharacterActionType
    {
        None = 0,
        Idle = 1,
        Feed = 2,
        Attack = 3,
        Travel = 4,
        Flee = 5,
        Sleep = 6,
        Relax = 7,
        AttackPrepare = 8,
        AttackCooldown = 9,
        Search = 10,
    }
}
