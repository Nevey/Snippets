﻿using System;
using Stranded.Characters.Combat.Defending;
using Stranded.Characters.Combat.Targeting;
using Stranded.Stats;
using UnityEngine;

namespace Stranded.Characters.Combat.Attacking
{
    public class Damageable : MonoBehaviour
    {
        [Header("Defenses")]
        [SerializeField, Tooltip("May be empty/null")] private Blockable blockable;

        [Header("Visual Effects")]
        [SerializeField, Tooltip("May be empty/null")] private GameObject spawnOnDeathPrefab;

        private StatsController statsController;
        private IStat healthStat;

        public event Action<Targetable> HurtByTargetableEvent;
        public event Action KilledEvent;

        private void Start()
        {
            statsController = GetComponent<StatsController>();

            if (statsController == null)
            {
                throw Log.Exception($"Unable to find a StatsController on {gameObject.name}");
            }

            healthStat = statsController.GetStat(StatType.Health);

            if (healthStat != null)
            {
                healthStat.DepletedEvent += OnHealthStatDepleted;
            }
        }

        private void OnDestroy()
        {
            if (healthStat != null)
            {
                healthStat.DepletedEvent -= OnHealthStatDepleted;
            }
        }

        private void OnHealthStatDepleted(IStat stat)
        {
            if (spawnOnDeathPrefab != null)
            {
                Instantiate(spawnOnDeathPrefab, transform.position, Quaternion.identity);
            }

            KilledEvent?.Invoke();

            Destroy(gameObject);
        }

        // TODO: Create HurtFailureReason to get rid of double bool shizzle
        public bool Hurt(int value, Targetable damageDoneBy, out bool isBlocking)
        {
            isBlocking = false;

            if (healthStat == null)
            {
                return false;
            }

            if (blockable != null && blockable.IsBlocking)
            {
                isBlocking = true;
                return false;
            }

            if (damageDoneBy != null)
            {
                HurtByTargetableEvent?.Invoke(damageDoneBy);
            }

            healthStat.Decrement(value);
            statsController.AlertStats(5f, 5f, healthStat);

            return true;
        }
    }
}
