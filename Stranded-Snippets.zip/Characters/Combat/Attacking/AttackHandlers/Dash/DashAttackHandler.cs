using UnityEngine;

public class DashAttackHandler : AttackHandler<DashAttackHandlerData>
{
    private Vector3 dashDirection;
    private float myHeight;

    protected override void OnStartAttack()
    {
        dashDirection = (data.target.transform.position - data.myTransform.position).normalized;

        Vector3 castOrigin = data.myTransform.position;
        castOrigin.y += 50f;

        if (Physics.Raycast(castOrigin, Vector3.down, out RaycastHit hit, 100f, 1 << 8))
        {
            myHeight = data.myTransform.position.y - hit.point.y;
        }
    }

    protected override void OnFinishAttack()
    {

    }

    protected override void OnUpdateAttack(float deltaTime)
    {
        // Move in a direction
        Vector3 dashDistance = dashDirection * data.speed * deltaTime;
        data.myTransform.position += dashDistance;

        // Set cast origin quite high above me
        Vector3 castOrigin = data.myTransform.position;
        castOrigin.y += 50f;

        // Find ground and stick to it
        if (Physics.Raycast(castOrigin, Vector3.down, out RaycastHit hit, 100f, 1 << 8))
        {
            Vector3 position = hit.point;
            position.y += myHeight;

            data.myTransform.position = position;
        }

        // If we failed, it was blocked, and we are interrupted
        if (!DoAttack(data.target))
        {
            FinishAttack();
        }
    }
}
