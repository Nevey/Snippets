using Stranded.Characters.Combat.Attacking;
using Stranded.Characters.Combat.Targeting;
using UnityEngine;

public class DashAttackHandlerData : AttackHandlerData
{
    public readonly Transform myTransform;

    public DashAttackHandlerData(Targetable target, AttackArea attackArea, float speed, float duration, Transform myTransform)
        : base(target, attackArea, speed, duration)
    {
        this.myTransform = myTransform;
    }
}
