using Stranded.Characters.Combat.Attacking;
using Stranded.Characters.Combat.Targeting;

public class AttackHandlerData
{
    public readonly Targetable target;
    public readonly AttackArea attackArea;
    public readonly float speed;
    public readonly float duration;

    public AttackHandlerData(Targetable target, AttackArea attackArea, float speed, float duration)
    {
        this.target = target;
        this.attackArea = attackArea;
        this.speed = speed;
        this.duration = duration;
    }
}
