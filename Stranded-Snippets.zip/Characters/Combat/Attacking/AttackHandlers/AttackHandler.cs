using System;
using Stranded.Characters.Combat.Targeting;

public abstract class AttackHandler
{
    protected float currentDuration;

    protected abstract void OnFinishAttack();
    protected abstract void OnUpdateAttack(float deltaTime);

    public event Action AttackFinishedEvent;

    public void FinishAttack()
    {
        OnFinishAttack();

        AttackFinishedEvent?.Invoke();
    }

    public virtual void UpdateAttack(float deltaTime)
    {
        currentDuration += deltaTime;

        OnUpdateAttack(deltaTime);
    }
}

public abstract class AttackHandler<T> : AttackHandler
    where T : AttackHandlerData
{
    protected T data;
    protected Func<Targetable, bool> DoAttack;

    protected abstract void OnStartAttack();

    public void StartAttack(T data, Func<Targetable, bool> DoAttack)
    {
        this.data = data;
        this.DoAttack = DoAttack;

        OnStartAttack();
    }

    public override void UpdateAttack(float deltaTime)
    {
        base.UpdateAttack(deltaTime);

        if (currentDuration >= data.duration)
        {
            FinishAttack();
        }
    }
}
