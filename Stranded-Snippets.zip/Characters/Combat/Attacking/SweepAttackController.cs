﻿using System;
using Stranded.Characters.Animations;
using Stranded.Characters.Combat.Targeting;
using UnityEngine;

namespace Stranded.Characters.Combat.Attacking
{
    public enum AttackState
    {
        None,
        InitialSweep,
        SweepRightToLeft,
        SweepLeftToRight,
        Cooldown,
    }

    public struct AttackArgs
    {
        public AttackState previousAttackState;
        public AttackState attackState;
        public float attackDuration;
        public float cooldownDuration;
    }

    // TODO: Make it extend the AttackController
    public class SweepAttackController : MonoBehaviour
    {
        [Header("Attack Timings")]
        [SerializeField] private float attackDuration = 0.5f;
        [SerializeField] private float chainWindowDuration = 1f;
        [SerializeField] private float cooldownDuration = 1f;

        [Header("Attack Basics")]
        [SerializeField] private int strength = 50;
        [SerializeField] private float attackRadius = 0.5f;
        [SerializeField] private float attackOffset;

        [Header("Optional Settings")]
        [SerializeField] private Transform body;

        [AnimationLink] protected AttackState attackState;

        private bool isAttacking;
        private Targetable myTargetable;

        public event Action<AttackArgs> AttackStartedEvent;
        public event Action AttackFinishedEvent;
        public event Action ChainFinishedEvent;

        protected virtual void Awake()
        {
            myTargetable = GetComponent<Targetable>();

            if (body == null)
            {
                body = transform;
            }
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;



            Vector3 localAttackOffset = (body == null ? transform.forward : body.forward) * attackOffset;
            Gizmos.DrawWireSphere((body == null ? transform.position : body.position) + localAttackOffset, attackRadius);
        }

        protected bool TryStartAttack()
        {
            switch (attackState)
            {
                default:
                    if (!isAttacking)
                    {
                        StartAttack();
                        return true;
                    }

                    return false;

                case AttackState.Cooldown:
                    return false;
            }
        }

        private void StartAttack()
        {
            AttackState previousAttackState = attackState;

            switch (attackState)
            {
                case AttackState.None:
                    attackState = AttackState.InitialSweep;
                    break;

                case AttackState.InitialSweep:
                    attackState = AttackState.SweepLeftToRight;
                    break;

                case AttackState.SweepLeftToRight:
                    attackState = AttackState.SweepRightToLeft;
                    break;

                case AttackState.SweepRightToLeft:
                    attackState = AttackState.SweepLeftToRight;
                    break;
            }

            isAttacking = true;
            CancelInvoke(nameof(ChainFinished));

            Invoke(nameof(DoDamage), attackDuration / 2f);
            Invoke(nameof(AttackFinished), attackDuration);
            Invoke(nameof(ChainFinished), chainWindowDuration);

            AttackArgs attackArgs = new AttackArgs
            {
                previousAttackState = previousAttackState,
                attackState = attackState,
                attackDuration = attackDuration,
                cooldownDuration = cooldownDuration
            };

            AttackStartedEvent?.Invoke(attackArgs);
        }

        private void DoDamage()
        {
            Vector3 localAttackOffset = body.forward * attackOffset;

            RaycastHit[] hits = Physics.SphereCastAll(body.position + localAttackOffset, attackRadius, transform.forward, 0.01f);

            for (int i = 0; i < hits.Length; i++)
            {
                if (hits[i].collider.isTrigger)
                {
                    continue;
                }

                Transform other = hits[i].transform;

                if (other == transform)
                {
                    continue;
                }

                Damageable otherDamageable = other.gameObject.GetComponent<Damageable>();

                if (otherDamageable == null)
                {
                    continue;
                }

                if (!otherDamageable.Hurt(strength, myTargetable, out bool isBlocking))
                {
                    if (isBlocking)
                    {
                        // TODO: Handle blocked animation etc.
                    }
                }
            }
        }

        private void AttackFinished()
        {
            isAttacking = false;
            AttackFinishedEvent?.Invoke();
        }

        private void ChainFinished()
        {
            ChainFinishedEvent?.Invoke();

            attackState = AttackState.Cooldown;
            Invoke(nameof(CooldownFinished), cooldownDuration);
        }

        private void CooldownFinished()
        {
            attackState = AttackState.None;
        }
    }
}
