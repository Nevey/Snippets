using System.Collections.Generic;
using UnityEngine;

namespace Stranded.Characters.Combat.Attacking
{
    public class AttackArea : MonoBehaviour
    {
        [SerializeField] private float attackRadius = 1f;
        [SerializeField] private Vector3 attackAreaOffset;

        private void OnDrawGizmos()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position + attackAreaOffset, attackRadius);
        }

        public Damageable[] GetAllDamageablesInArea()
        {
            RaycastHit[] hits = Physics.SphereCastAll(transform.position + attackAreaOffset, attackRadius, transform.forward, 0.01f);

            List<Damageable> damageablesInArea = new List<Damageable>(); ;

            for (int i = 0; i < hits.Length; i++)
            {
                if (!hits[i].collider.isTrigger
                    && hits[i].collider.TryGetComponent<Damageable>(out Damageable damageable)
                    && !damageablesInArea.Contains(damageable))
                {
                    damageablesInArea.Add(damageable);
                }
            }

            return damageablesInArea.ToArray();
        }
    }
}
