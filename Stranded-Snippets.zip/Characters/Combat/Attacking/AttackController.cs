using System.Collections.Generic;
using System.Linq;
using Stranded.Characters.Combat.Targeting;
using UnityEngine;

namespace Stranded.Characters.Combat.Attacking
{
    public abstract class AttackController : MonoBehaviour
    {
        [Header("Attack Settings")]
        [SerializeField] private int attackStrength = 20;

        [Header("Attack Refs")]
        [SerializeField] protected AttackArea attackArea;

        private readonly List<Damageable> damageablesPreviouslyHurt = new List<Damageable>();

        protected void PrepareNewAttack()
        {
            damageablesPreviouslyHurt.Clear();
        }

        protected bool DoAttack(Targetable damageDoneBy)
        {
            List<Damageable> damageablesToHurt = attackArea.GetAllDamageablesInArea().ToList();

            for (int i = damageablesPreviouslyHurt.Count - 1; i >= 0; i--)
            {
                if (damageablesToHurt.Contains(damageablesPreviouslyHurt[i]))
                {
                    damageablesToHurt.Remove(damageablesPreviouslyHurt[i]);
                    continue;
                }

                damageablesPreviouslyHurt.RemoveAt(i);
            }

            for (int i = 0; i < damageablesToHurt.Count; i++)
            {
                if (damageablesToHurt[i].gameObject == gameObject)
                {
                    continue;
                }

                if (!damageablesToHurt[i].Hurt(attackStrength, damageDoneBy, out bool isBlocked))
                {
                    if (isBlocked)
                    {
                        return false;
                    }

                    continue;
                }

                damageablesPreviouslyHurt.Add(damageablesToHurt[i]);
            }

            return true;
        }
    }
}
