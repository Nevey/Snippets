using System;
using System.Collections.Generic;
using CardboardCore.DI;
using Stranded.Characters.Animations;
using Stranded.Characters.Combat.Targeting;
using UnityEngine;

[RequireComponent(typeof(SphereCollider))]
public class TargetingController : CardboardCoreBehaviour
{
    [SerializeField] private float targetingRadius;

    [AnimationLink] protected Targetable selectedTarget;

    private readonly List<Targetable> targetablesInRange = new List<Targetable>();

    public float TargetingRadius => targetingRadius;
    public Targetable SelectedTarget => selectedTarget;

    public event Action TargetableSelectedEvent;
    public event Action TargetableUnselectedEvent;

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, targetingRadius);
    }

    private void OnValidate()
    {
        SphereCollider sphereCollider = GetComponent<SphereCollider>();

        // For some reason, spherecollider radius is twice as small as it should be?
        sphereCollider.radius = targetingRadius * 2;
        sphereCollider.isTrigger = true;
    }

    private void OnTriggerEnter(Collider other)
    {
        Targetable targetable = other.GetComponent<Targetable>();

        if (targetable == null)
        {
            return;
        }

        targetablesInRange.Add(targetable);

        targetable.DestroyedEvent += OnTargetableDestroyed;
    }

    private void OnTriggerExit(Collider other)
    {
        Targetable targetable = other.GetComponent<Targetable>();

        if (targetable == null || !targetablesInRange.Contains(targetable))
        {
            return;
        }

        RemoveTargetable(targetable);
    }

    private void OnTargetableDestroyed(Targetable targetable)
    {
        RemoveTargetable(targetable);
    }

    private void RemoveTargetable(Targetable targetable)
    {
        targetablesInRange.Remove(targetable);

        targetable.DestroyedEvent -= OnTargetableDestroyed;

        if (targetable == selectedTarget)
        {
            UnselectCurrentTarget();
        }
    }

    protected void SelectNextTarget(TargetableFlags targetedBy, int tries = 20)
    {
        if (tries == 0 || targetablesInRange.Count == 0)
        {
            return;
        }

        int currentTargetIndex = -1;

        if (selectedTarget != null)
        {
            currentTargetIndex = targetablesInRange.IndexOf(selectedTarget);
            UnselectCurrentTarget();
        }

        currentTargetIndex++;
        currentTargetIndex %= targetablesInRange.Count;

        selectedTarget = targetablesInRange[currentTargetIndex];

        if (!selectedTarget.TargetableBy.HasFlag(targetedBy))
        {
            SelectNextTarget(targetedBy, --tries);
            return;
        }

        selectedTarget.Select(targetedBy);

        TargetableSelectedEvent?.Invoke();
    }

    protected void SelectRandomTarget(TargetableFlags targetedBy, int tries = 20)
    {
        if (tries == 0)
        {
            return;
        }

        if (selectedTarget != null)
        {
            UnselectCurrentTarget();
        }

        int randomIndex = UnityEngine.Random.Range(0, targetablesInRange.Count);
        Targetable randomTarget = targetablesInRange[randomIndex];

        if (!randomTarget.TargetableBy.HasFlag(targetedBy))
        {
            SelectRandomTarget(targetedBy, --tries);
            return;
        }

        randomTarget.Select(targetedBy);

        TargetableSelectedEvent?.Invoke();
    }

    protected void SelectSpecificTarget(TargetableFlags targetedBy, Targetable target)
    {
        if (selectedTarget != null)
        {
            selectedTarget.Unselect();
        }

        selectedTarget = target;
        selectedTarget.Select(targetedBy);

        TargetableSelectedEvent?.Invoke();
    }

    protected void UnselectCurrentTarget()
    {
        if (selectedTarget == null)
        {
            return;
        }

        selectedTarget.Unselect();
        selectedTarget = null;

        TargetableUnselectedEvent?.Invoke();
    }
}
