using CardboardCore.DI;
using System;
using UnityEngine;

namespace Stranded.Characters.Combat.Targeting
{
    [Flags]
    public enum TargetableFlags
    {
        Player = 1,
        AI = 2
    }

    public abstract class Targetable : CardboardCoreBehaviour
    {
        [SerializeField] private TargetableFlags targetableBy;

        protected TargetableFlags targetedBy;

        public TargetableFlags TargetableBy => targetableBy;

        public event Action<Targetable> DestroyedEvent;

        protected override void OnDestroy()
        {
            DestroyedEvent?.Invoke(this);

            base.OnDestroy();
        }

        protected abstract void OnSelect();
        protected abstract void OnDeselect();

        public void Select(TargetableFlags targetedBy)
        {
            this.targetedBy = targetedBy;
            OnSelect();
        }

        public void Unselect()
        {
            OnDeselect();
        }
    }
}
