using CardboardCore.DI;
using CardboardCore.Pooling;
using UnityEngine;
using UnityEngine.Rendering.HighDefinition;

namespace Stranded.Characters.Combat.Targeting
{
    public class TargetableWithVisuals : Targetable
    {
        [SerializeField] private PoolConfig poolConfig;
        [SerializeField] private Vector3 decalOffset;
        [SerializeField] private TargetableFlags showVisualsWhenTargetedBy;

        [Inject] private PoolController poolController;

        private DecalProjector decalProjector;

        protected override void OnDestroy()
        {
            HideDecal();

            base.OnDestroy();
        }

        private void LateUpdate()
        {
            if (decalProjector == null)
            {
                return;
            }

            decalProjector.transform.localPosition = transform.position + decalOffset;
        }

        private void ShowDecal()
        {
            decalProjector = poolController.Pop<DecalProjector>(poolConfig, DecalPoolConfigNames.SelectedTargetDecal);
        }

        private void HideDecal()
        {
            poolController.Push(poolConfig, decalProjector);
            decalProjector = null;
        }

        protected override void OnSelect()
        {
            if (!showVisualsWhenTargetedBy.HasFlag(targetedBy))
            {
                return;
            }

            ShowDecal();
        }

        protected override void OnDeselect()
        {
            if (!showVisualsWhenTargetedBy.HasFlag(targetedBy))
            {
                return;
            }

            HideDecal();
        }
    }
}
