using UnityEngine;

namespace Stranded.Characters.Combat.Defending
{
    public class Blockable : MonoBehaviour
    {
        [SerializeField] private bool canDetach;

        private bool isBlocking;

        public bool CanDetach => canDetach;
        public bool IsBlocking => isBlocking;

        public void StartBlock()
        {
            isBlocking = true;
        }

        public void StopBlock()
        {
            isBlocking = false;
        }
    }
}
