using System;
using Stranded.Characters.Animations;
using UnityEngine;

namespace Stranded.Characters.Combat.Defending
{
    public enum BlockState
    {
        None,
        Block,
        DetachedBlock,
        Counter
    }

    public struct BlockArgs
    {
        public BlockState BlockState;
    }

    public class BlockController : MonoBehaviour
    {
        [SerializeField] private Blockable blockable;

        [AnimationLink] protected BlockState blockState;

        private BlockArgs blockArgs = new BlockArgs();

        public event Action<BlockArgs> BlockUpdatedEvent;

        protected bool TryBlock()
        {
            switch (blockState)
            {
                case BlockState.None:
                    StartBlock();
                    return true;

                default:
                    return false;
            }
        }

        protected bool TryStopBlock()
        {
            switch (blockState)
            {
                case BlockState.Block:
                    StopBlock();
                    return true;

                default:
                    return false;
            }
        }

        private void StartBlock()
        {
            blockState = BlockState.Block;
            blockable.StartBlock();

            blockArgs.BlockState = blockState;
            BlockUpdatedEvent?.Invoke(blockArgs);
        }

        private void StopBlock()
        {
            blockState = BlockState.None;
            blockable.StopBlock();

            blockArgs.BlockState = blockState;
            BlockUpdatedEvent?.Invoke(blockArgs);
        }
    }
}
