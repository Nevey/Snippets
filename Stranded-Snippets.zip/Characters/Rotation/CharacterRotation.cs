using System;
using DG.Tweening;
using UnityEngine;

namespace Stranded.Characters.Rotation
{
    [Flags]
    public enum RotationRestriction
    {
        X = 1,
        Y = 2,
        Z = 4
    }

    [RequireComponent(typeof(Rigidbody))]
    public abstract class CharacterRotation : MonoBehaviour
    {
        [SerializeField] private RotationData rotationData;
        [SerializeField] private RotationRestriction rotationRestriction;
        [SerializeField] private bool mayDoRotateUpside;

        private new Rigidbody rigidbody;
        private Quaternion targetRotation;
        private Tween rotateUpsideTween;

        protected bool mayRotate;

        protected virtual void Awake()
        {
            rigidbody = GetComponent<Rigidbody>();
            mayRotate = true;
        }

        private void OnDestroy()
        {
            rotateUpsideTween?.Kill();
        }

        private void FixedUpdate()
        {
            if (!mayRotate)
            {
                return;
            }

            Vector3 euler = targetRotation.eulerAngles;
            euler.x = rotationRestriction.HasFlag(RotationRestriction.X) ? rigidbody.rotation.eulerAngles.x : euler.x;
            euler.y = rotationRestriction.HasFlag(RotationRestriction.Y) ? rigidbody.rotation.eulerAngles.y : euler.y;
            euler.z = rotationRestriction.HasFlag(RotationRestriction.Z) ? rigidbody.rotation.eulerAngles.z : euler.z;

            rigidbody.rotation = Quaternion.RotateTowards(rigidbody.rotation, Quaternion.Euler(euler), rotationData.RotationSpeed);
        }

        protected void SetTargetRotation(Quaternion rotation)
        {
            targetRotation = rotation;
        }

        /// <summary>
        /// Override default settings and rotate this character upside.
        /// </summary>
        public void RotateUpside(float duration, Action callback = null)
        {
            if (!mayDoRotateUpside)
            {
                return;
            }

            Vector3 targetEuler = targetRotation.eulerAngles;
            targetEuler.x = 0f;
            targetEuler.z = 0f;

            rotateUpsideTween?.Kill();

            rotateUpsideTween = rigidbody.DORotate(targetEuler, 0.5f).OnComplete(() =>
            {
                callback?.Invoke();
            });
        }
    }
}
