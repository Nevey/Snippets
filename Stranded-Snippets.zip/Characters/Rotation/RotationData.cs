using System;
using UnityEngine;

namespace Stranded.Characters.Rotation
{
    [Serializable]
    public class RotationData
    {
        [SerializeField] private float rotationSpeed = 5f;

        public float RotationSpeed => rotationSpeed;
    }
}
