﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace Stranded.Characters.Movement
{
    public class CarvingRequest
    {
        public Renderer Renderer;
        public float TimeLeft;
    }
    
    [RequireComponent(typeof(NavMeshObstacle))]
    public class CharacterNavMeshCarver : MonoBehaviour
    {
        [SerializeField] private new Renderer renderer;
        [SerializeField] private float carveRequestLifespan = 2f;
        [SerializeField] private float carveInterval = 0.5f;

        private NavMeshObstacle navMeshObstacle;
        private readonly List<CarvingRequest> carvingRequests = new List<CarvingRequest>();

        private void Awake()
        {
            navMeshObstacle = GetComponent<NavMeshObstacle>();
            navMeshObstacle.carveOnlyStationary = false;
            navMeshObstacle.carvingMoveThreshold = 0.2f;
            navMeshObstacle.shape = NavMeshObstacleShape.Box;
        }

        private void OnDestroy()
        {
            carvingRequests.Clear();
            navMeshObstacle.carving = false;
            StopAllCoroutines();
        }

        private bool CarvingRequestsContains(Renderer renderer, out CarvingRequest carvingRequest)
        {
            carvingRequest = null;

            for (int i = 0; i < carvingRequests.Count; i++)
            {
                if (carvingRequests[i].Renderer == renderer)
                {
                    carvingRequest = carvingRequests[i];
                    break;
                }
            }
            
            return carvingRequest != null;
        }

        private IEnumerator CarveEnumerator()
        {
            navMeshObstacle.carving = true;

            while (carvingRequests.Count > 0)
            {
                for (int i = 0; i < carvingRequests.Count; i++)
                {
                    if (carvingRequests[i].Renderer == null || carvingRequests[i].Renderer.gameObject == null)
                    {
                        carvingRequests.RemoveAt(i);
                        continue;
                    }

                    Vector3 requestSize = carvingRequests[i].Renderer.bounds.size;
                    requestSize = requestSize.magnitude < renderer.bounds.size.magnitude
                        ? renderer.bounds.size
                        : requestSize;

                    if (requestSize.magnitude > navMeshObstacle.size.magnitude)
                    {
                        navMeshObstacle.size = requestSize;
                    }
                    
                    yield return new WaitForSeconds(carveInterval);
                    
                    carvingRequests[i].TimeLeft -= carveInterval;

                    if (carvingRequests[i].TimeLeft <= 0f)
                    {
                        carvingRequests.RemoveAt(i);
                    }
                }
            }
            
            navMeshObstacle.carving = false;
        }

        public void RequestCarving(GameObject gameObject)
        {
            Renderer renderer = gameObject.GetComponentInChildren<Renderer>();

            if (renderer == null)
            {
                throw Log.Exception($"No Renderer attached to GameObject {gameObject.name}");
            }

            if (CarvingRequestsContains(renderer, out CarvingRequest carvingRequest))
            {
                carvingRequest.TimeLeft = carveRequestLifespan;
                return;
            }

            carvingRequest = new CarvingRequest
            {
                Renderer = renderer,
                TimeLeft = carveRequestLifespan
            };
            
            carvingRequests.Add(carvingRequest);

            if (!navMeshObstacle.carving)
            {
                StartCoroutine(CarveEnumerator());
            }
        }
    }
}