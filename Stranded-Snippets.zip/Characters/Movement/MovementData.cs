using System;
using UnityEngine;

namespace Stranded.Characters.Movement
{
    [Serializable]
    public class MovementData
    {
        [SerializeField] private float movementStrength = 20f;
        [SerializeField] private float walkMaxMovementSpeed = 7.5f;
        [SerializeField] private float runMaxMovementSpeed = 12.5f;
        [SerializeField] private float counterMovementStrength = 20f;

        public float MovementStrength => movementStrength;
        public float WalkMaxMovementSpeed => walkMaxMovementSpeed;
        public float RunMaxMovementSpeed => runMaxMovementSpeed;
        public float CounterMovementStrength => counterMovementStrength;
    }
}
