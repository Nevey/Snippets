using System;
using UnityEngine;

public enum MovementType
{
    None,
    Continuous,
    ContinuousHops,
    SingleHop
}

[Serializable]
public class MovementTypeData
{
    [SerializeField] private MovementType movementType;
    [SerializeField] private float hopBuildup = 0.5f;
    [SerializeField] private float upwardHopStrength = 5f;
    [SerializeField] private float forwardHopStrength = 5f;
    [SerializeField] private float singleHopCooldown = 1f;

    public MovementType MovementType => movementType;
    public float HopBuildup => hopBuildup;
    public float UpwardHopStrength => upwardHopStrength;
    public float ForwardHopStrength => forwardHopStrength;
    public float SingeHopCooldown => singleHopCooldown;
}
