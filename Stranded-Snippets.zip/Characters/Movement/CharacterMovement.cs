using Stranded.Characters.Animations;
using UnityEngine;

namespace Stranded.Characters.Movement
{
    [RequireComponent(typeof(Rigidbody))]
    public abstract class CharacterMovement : MonoBehaviour
    {
        [SerializeField] private MovementData movementData;
        [SerializeField] private MovementTypeData movementTypeData;

        protected new Rigidbody rigidbody;
        [AnimationLink] private Vector3 movementDirection;
        private bool mayHop;
        private float relativeMultiplier;

        private MovementType? movementTypeOverride;

        public MovementData MovementData => movementData;
        public MovementTypeData MovementTypeData => movementTypeData;

        protected virtual void Awake()
        {
            rigidbody = GetComponent<Rigidbody>();
        }

        protected virtual void OnDestroy()
        {

        }

        protected virtual void Update()
        {

        }

        protected virtual void FixedUpdate()
        {
            switch (movementTypeOverride ?? movementTypeData.MovementType)
            {
                case MovementType.Continuous:
                    ApplyContinuousMovement();
                    break;

                case MovementType.ContinuousHops:
                    DoHop();
                    break;

                case MovementType.SingleHop:
                    DoHop();
                    break;
            }
        }

        private void LateUpdate()
        {
            switch (movementTypeOverride ?? movementTypeData.MovementType)
            {
                case MovementType.Continuous:
                    ClampVelocity();
                    break;

                case MovementType.ContinuousHops:
                    break;

                case MovementType.SingleHop:
                    break;
            }
        }

        protected virtual void OnCollisionEnter(Collision other)
        {
            // When hopping on top of ground or another character...
            if (other.gameObject.layer == 8 || other.gameObject.layer == 9)
            {
                switch (movementTypeData.MovementType)
                {
                    case MovementType.Continuous:

                        break;

                    case MovementType.ContinuousHops:
                        AllowHop();
                        break;

                    case MovementType.SingleHop:
                        CancelInvoke(nameof(AllowHop));
                        Invoke(nameof(AllowHop), movementTypeData.SingeHopCooldown);
                        break;
                }
            }
        }

        private void ApplyContinuousMovement()
        {
            rigidbody.AddForce(movementDirection * movementData.MovementStrength, ForceMode.Acceleration);

            if (movementDirection == Vector3.zero && rigidbody.velocity.magnitude > 0.5f)
            {
                Vector3 counter = -rigidbody.velocity.normalized;
                counter.y = 0f;
                rigidbody.AddForce(counter * movementData.CounterMovementStrength, ForceMode.Acceleration);
            }
        }

        private void ClampVelocity()
        {
            Vector3 velocity = rigidbody.velocity;
            velocity = Vector3.ClampMagnitude(velocity, movementData.WalkMaxMovementSpeed);
            velocity.y = rigidbody.velocity.y;
            rigidbody.velocity = velocity;
        }

        private void DoHop()
        {
            if (!mayHop || movementDirection == Vector3.zero)
            {
                return;
            }

            Vector3 forceInDirection = movementDirection.normalized * movementTypeData.ForwardHopStrength;
            forceInDirection.y = movementTypeData.UpwardHopStrength;

            rigidbody.AddForce(forceInDirection, ForceMode.Acceleration);

            mayHop = false;

            if (movementTypeData.MovementType == MovementType.ContinuousHops)
            {
                CancelInvoke(nameof(AllowHop));
                // Allow for hopping if I didn't succeed for too long
                Invoke(nameof(AllowHop), 10f);
            }
        }

        protected void AllowHop()
        {
            mayHop = true;
        }

        protected void MoveInDirection(Vector3 direction)
        {
            movementDirection = direction;
        }

        protected void SetPosition(Vector3 position)
        {
            if (rigidbody.isKinematic)
            {
                rigidbody.MovePosition(position);
            }
            else
            {
                rigidbody.position = position;
            }
        }

        protected void OverrideMovementType(MovementType movementType)
        {
            movementTypeOverride = movementType;
        }

        protected void ResetMovementTypeOverride()
        {
            movementTypeOverride = null;
        }

        public void Stop()
        {
            rigidbody.isKinematic = true;
            rigidbody.detectCollisions = false;
        }
    }
}
