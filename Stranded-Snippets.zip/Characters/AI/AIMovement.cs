using System;
using System.Collections;
using System.Collections.Generic;
using Stranded.Characters.Movement;
using UnityEngine;
using UnityEngine.AI;

namespace Stranded.Characters.AI
{
    [AddComponentMenu("Stranded/Characters/AI/AIMovement")]
    [RequireComponent(typeof(AITargeting))]
    [RequireComponent(typeof(AISurroundingsAwareness))]
    public class AIMovement : CharacterMovement
    {
        [Header("AIMovement Settings")]
        [SerializeField] private float updateInterval = 0.2f;
        [SerializeField] private bool ignoreFollowers;
        [SerializeField] private float distanceForWaypointReached = 2f;
        [SerializeField] private bool debug;

        private enum MovementMode
        {
            None,
            FollowPath,
            Flee
        }

        private AIController aiController;
        private AITargeting aiTargeting;
        private AISurroundingsAwareness aiSurroundingsAwareness;

        private MovementMode movementMode;
        private readonly List<Vector3> path = new List<Vector3>();

        public event Action DestinationReachedEvent;

        protected override void Awake()
        {
            base.Awake();

            aiController = GetComponent<AIController>();
            aiTargeting = GetComponent<AITargeting>();
            aiSurroundingsAwareness = GetComponent<AISurroundingsAwareness>();

            movementMode = MovementMode.None;
        }

        private void Start()
        {
            StartCoroutine(PathHandlingEnumerator());
        }

        protected override void OnDestroy()
        {
            StopAllCoroutines();
        }

        protected override void Update()
        {
            base.Update();

            switch (movementMode)
            {
                case MovementMode.None:
                    break;

                case MovementMode.FollowPath:
                    FollowPath();
                    break;

                case MovementMode.Flee:
                    break;
            }


            for (int i = 0; i < path.Count; i++)
            {
                int k = i + 1;

                Vector3 from = i == 0 ? transform.position : path[i];
                Vector3 to = k >= path.Count ? aiTargeting.TargetPosition : path[k];
                Vector3 pathDirection = to - from;

                if (debug)
                {
                    Debug.DrawRay(from, pathDirection, Color.blue);
                }
            }

            if (debug)
            {
                Debug.DrawRay(aiTargeting.TargetPosition, Vector3.up, Color.magenta);
            }
        }

        private void OnDrawGizmosSelected()
        {
            if (!debug)
            {
                return;
            }

            Color color = Color.magenta;
            color.a = 0.2f;
            Gizmos.color = color;

            Gizmos.DrawSphere(transform.position, distanceForWaypointReached);
        }

        private IEnumerator PathHandlingEnumerator()
        {
            while (true)
            {
                yield return new WaitForSeconds(updateInterval);

                switch (movementMode)
                {
                    case MovementMode.None:
                        break;

                    case MovementMode.FollowPath:
                        CalculatePath();
                        CheckForObstacles();
                        break;

                    case MovementMode.Flee:
                        break;
                }

                if (aiSurroundingsAwareness.IsPointInAwarenessRange(aiTargeting.TargetPosition))
                {
                    DestinationReachedEvent?.Invoke();
                }
            }
        }

        private void FollowPath()
        {
            // If this happens, we were unable to reach our destination via our path, so we want to re-calculate our path again...
            if (path.Count == 0)
            {
                CalculatePath();
                return;
            }

            Vector3 nextCorner = path[0];

            Vector3 direction = (nextCorner - transform.position).normalized;

            MoveInDirection(direction);

            if (debug)
            {
                Debug.DrawRay(transform.position, direction, Color.cyan);
            }

            // Check if we reached our waypoint
            float distanceFromWaypoint = Vector3.Distance(nextCorner, transform.position);

            if (distanceFromWaypoint < distanceForWaypointReached)
            {
                path.RemoveAt(0);
            }
        }

        private void CalculatePath()
        {
            Vector3 normalizedDirection = (aiTargeting.TargetPosition - transform.position).normalized;
            if (!NavMesh.SamplePosition(transform.position + normalizedDirection, out NavMeshHit startHit, 10f, NavMesh.AllAreas))
            {
                Log.Warn($"{gameObject.name} can't find Path Start Point");

                DestinationReachedEvent?.Invoke();
                return;
            }

            if (!NavMesh.SamplePosition(aiTargeting.TargetPosition, out NavMeshHit endHit, 10f, NavMesh.AllAreas))
            {
                Log.Warn($"{gameObject.name} can't find Path End Point");

                DestinationReachedEvent?.Invoke();
                return;
            }

            NavMeshPath navMeshPath = new NavMeshPath();
            NavMesh.CalculatePath(startHit.position, endHit.position, NavMesh.AllAreas, navMeshPath);

            path.Clear();
            path.AddRange(navMeshPath.corners);
        }

        private void CheckForObstacles()
        {
            bool obstacleFound = false;

            for (int i = 0; i < path.Count; i++)
            {
                int k = i + 1;

                bool isFinalWaypoint = k >= path.Count;

                Vector3 from = isFinalWaypoint ? transform.position : path[i];
                Vector3 to = isFinalWaypoint ? path[i] : path[k];
                Vector3 pathDirection = to - from;

                RaycastHit[] hits = Physics.BoxCastAll(from, Vector3.one * 2f, pathDirection.normalized,
                    Quaternion.identity, pathDirection.magnitude);

                for (int j = 0; j < hits.Length; j++)
                {
                    if (debug)
                    {
                        Debug.DrawRay(from, pathDirection, Color.red, updateInterval);
                    }

                    CharacterNavMeshCarver otherCharacterNavMeshCarver = hits[j].collider.GetComponentInParent<CharacterNavMeshCarver>();

                    if (otherCharacterNavMeshCarver == null || otherCharacterNavMeshCarver.transform == transform)
                    {
                        continue;
                    }

                    AIController otherAIController = otherCharacterNavMeshCarver.GetComponent<AIController>();

                    if (ignoreFollowers
                        && otherAIController != null && otherAIController.LeaderToFollow != null && otherAIController.LeaderToFollow == aiController)
                    {
                        continue;
                    }

                    otherCharacterNavMeshCarver.RequestCarving(gameObject);
                    obstacleFound = true;
                }
            }

            if (obstacleFound)
            {
                CalculatePath();
            }
        }

        public void StartMovingToTarget()
        {
            movementMode = MovementMode.FollowPath;
            CalculatePath();
            AllowHop();
        }

        public void StartMovingToTarget(Transform target)
        {
            aiTargeting.SetTarget(target);
            StartMovingToTarget();
        }

        public void StopMovement()
        {
            movementMode = MovementMode.None;
            MoveInDirection(Vector3.zero);
        }
    }
}
