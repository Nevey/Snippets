namespace Stranded.Characters.AI.StateMachines
{
    public class AICombatStateMachine<T> : AIStateMachine<T>
        where T : AIController
    {
        public AICombatStateMachine(T owner, bool enableDebugging) : base(owner, enableDebugging)
        {
            SetInitialState<AIGetInRangeForAttackState<T>>();
            AddTransition<AIGetInRangeForAttackState<T>, AIAttackPrepareState<T>>();
            AddTransition<AIAttackPrepareState<T>, AIAttackState<T>>();
            AddTransition<AIAttackState<T>, AIAttackCooldownState<T>>();
            AddTransition<AIAttackCooldownState<T>, AIGetInRangeForAttackState<T>>();

            SetOwnerForAllStates();
        }
    }
}
