namespace Stranded.Characters.AI.StateMachines
{
    public class AIRoamingLeaderStateMachine<T> : AIStateMachine<T>
        where T : AIController
    {
        public AIRoamingLeaderStateMachine(T owner, bool enableDebugging) : base(owner, enableDebugging)
        {
            SetInitialState<AIIdleState<T>>();
            AddTransition<AIIdleState<T>, AIFindFoodState<T>>();
            AddTransition<AIFindFoodState<T>, AITravelToTargetState<T>>();
            AddTransition<AITravelToTargetState<T>, AIFeedState<T>>();
            AddTransition<AIFeedState<T>, AIFindSleepSpotState<T>>();
            AddTransition<AIFindSleepSpotState<T>, AISleepState<T>>();
            AddTransition<AISleepState<T>, AIFindRelaxSpotState<T>>();
            AddTransition<AIFindRelaxSpotState<T>, AIRelaxState<T>>();
            AddTransition<AIRelaxState<T>, AIIdleState<T>>();

            SetOwnerForAllStates();
        }
    }
}
