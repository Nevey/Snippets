﻿using Stranded.Characters.Actions;
using Stranded.Characters.Needs;
using Stranded.Stats;

namespace Stranded.Characters.AI.StateMachines
{
    public class AIRelaxState<T> : AIReplenishNeedState<T>
        where T : AIController
    {
        protected override CharacterActionType CharacterActionType => CharacterActionType.Relax;
        protected override CharacterNeedType CharacterNeedType => CharacterNeedType.Relax;
        protected override StatType StatType => StatType.Relaxed;
    }
}
