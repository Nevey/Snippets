using Stranded.Characters.Actions;

namespace Stranded.Characters.AI.StateMachines
{
    public class AIIdleState<T> : AIState<T>
        where T : AIController
    {
        protected override CharacterActionType CharacterActionType => CharacterActionType.Idle;

        protected override bool ActionStartRequirementsFullfilled()
        {
            return true;
        }

        protected override bool ActionFinishRequirementsFulfilledIfDurationIsIgnored()
        {
            throw new System.NotImplementedException();
        }

        protected override void OnActionStarted()
        {
            Owner.AIMovement.StopMovement();
        }

        protected override void OnActionFinished()
        {
        }
    }
}
