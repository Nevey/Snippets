using System;
using CardboardCore.StateMachines;
using Stranded.Characters.Actions;

namespace Stranded.Characters.AI.StateMachines
{
    public abstract class AIState<T> : State
        where T : AIController
    {
        protected T Owner { get; private set; }
        protected abstract CharacterActionType CharacterActionType { get; }

        protected abstract bool ActionStartRequirementsFullfilled();
        protected abstract bool ActionFinishRequirementsFulfilledIfDurationIsIgnored();
        protected abstract void OnActionStarted();
        protected abstract void OnActionFinished();

        protected CharacterAction characterAction;

        private bool isExecuting;

        protected float ActionDuration => characterAction.Duration;

        internal void SetOwner(T owner)
        {
            Owner = owner;
        }

        protected override void OnEnter()
        {
            characterAction = Owner.CharacterActionController.GetAction(CharacterActionType);

            if (ActionStartRequirementsFullfilled())
            {
                // Only start the action if requirements are fulfilled
                StartAction();
            }
            else
            {
                // If requirements aren't fulfilled, immediately finish the action
                // This gives us the opportunity to clean things up as well
                FinishAction();
            }
        }

        protected override void OnExit()
        {
            // In case the action wasn't finished by itself
            Owner.CharacterActionController.CancelAction(false);
        }

        internal virtual void Update(float deltaTime)
        {
            if (isExecuting && characterAction.IgnoreDuration && ActionFinishRequirementsFulfilledIfDurationIsIgnored())
            {
                FinishAction();
            }
        }

        private void StartAction()
        {
            isExecuting = true;
            characterAction = Owner.CharacterActionController.StartAction(CharacterActionType, FinishAction);

            OnActionStarted();
        }

        private void FinishAction()
        {
            isExecuting = false;

            OnActionFinished();

            owningStateMachine.ToNextState();
        }
    }
}
