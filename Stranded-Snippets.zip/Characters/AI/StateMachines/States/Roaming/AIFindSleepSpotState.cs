﻿using Stranded.Characters.Actions;
using Stranded.Characters.Needs;

namespace Stranded.Characters.AI.StateMachines
{
    public class AIFindSleepSpotState<T> : AIFindNeedSpotState<T>
        where T : AIController
    {
        protected override CharacterNeedType CharacterNeedType => CharacterNeedType.Sleep;
        protected override CharacterActionType LeaderActionType => CharacterActionType.Sleep;
    }
}
