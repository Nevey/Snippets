using Stranded.Characters.Actions;
using Stranded.Characters.AI;
using Stranded.Characters.AI.StateMachines;
using Stranded.Characters.Needs;

public abstract class AIFindNeedSpotState<T> : AIState<T>
        where T : AIController
{
    /// <summary>
    /// The need type to check
    /// </summary>
    /// <value></value>
    protected abstract CharacterNeedType CharacterNeedType { get; }

    /// <summary>
    /// The action my leader (if any) has to do for us to follow
    /// </summary>
    /// <value></value>
    protected abstract CharacterActionType LeaderActionType { get; }

    protected override CharacterActionType CharacterActionType => CharacterActionType.Search;

    private CharacterNeed characterNeed;

    protected override bool ActionStartRequirementsFullfilled()
    {
        // Check if we're in need of food
        characterNeed = Owner.CharacterNeedController.GetNeed(CharacterNeedType);
        if (characterNeed == null)
        {
            return false;
        }

        // I'm not following a leader, so I can start finding a point based on my need where ever I want
        if (Owner.LeaderToFollow == null)
        {
            // I'm in need of something but not in range, so i'm allowed to start searching!
            return true;
        }

        // Check if we're following a leader and if this leader is doing the correct action to follow
        if (Owner.LeaderToFollow != null && Owner.LeaderToFollow.CharacterActionController.CharacterActionType != LeaderActionType)
        {
            return false;
        }

        // Check if the leader I'm following has a target selected
        if (Owner.LeaderToFollow.AITargeting.SelectedTarget == null)
        {
            return false;
        }

        // I'm in need of something, but it's not around...
        if (characterNeed.pointOfInterestTypes.Length == 0)
        {
            return false;
        }

        return true;
    }

    protected override bool ActionFinishRequirementsFulfilledIfDurationIsIgnored()
    {
        throw new System.NotImplementedException();
    }

    protected override void OnActionStarted()
    {
        // Select my leader's target
        if (Owner.LeaderToFollow && Owner.LeaderToFollow.AITargeting.SelectedTarget != null)
        {
            Owner.AITargeting.SetTarget(Owner.LeaderToFollow.AITargeting.SelectedTarget);
            return;
        }

        // Select my own target
        for (int i = 0; i < characterNeed.pointOfInterestTypes.Length; i++)
        {
            // TODO: Don't look through different POI Types, but all of them at the same time
            if (Owner.AITargeting.SetClosestTargetLocation(characterNeed.pointOfInterestTypes[i]))
            {
                break;
            }
        }
    }

    protected override void OnActionFinished()
    {

    }
}
