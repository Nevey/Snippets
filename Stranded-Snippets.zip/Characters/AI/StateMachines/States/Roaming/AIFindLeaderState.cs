﻿using Stranded.Characters.Actions;

namespace Stranded.Characters.AI.StateMachines
{
    public class AIFindLeaderState<T> : AIState<T> where T : AIController
    {
        protected override CharacterActionType CharacterActionType => CharacterActionType.Search;

        private AIController aiController;

        protected override bool ActionStartRequirementsFullfilled()
        {
            // I'm not following a leader...
            if (Owner.LeaderToFollow == null)
            {
                return false;
            }

            Owner.AISurroundingsAwareness.SetAlertedAwareness();

            return Owner.AISurroundingsAwareness.IsLeaderInRange(out aiController);
        }

        protected override bool ActionFinishRequirementsFulfilledIfDurationIsIgnored()
        {
            throw new System.NotImplementedException();
        }

        protected override void OnActionStarted()
        {
            Owner.SetLeaderToFollow(aiController);
            Owner.AITargeting.SetTarget(Owner.LeaderToFollow.AITargetable);
        }

        protected override void OnActionFinished()
        {
            Owner.AISurroundingsAwareness.SetDefaultAwareness();
        }
    }
}
