using Stranded.Characters.AI;
using Stranded.Characters.AI.StateMachines;
using Stranded.Characters.Needs;
using Stranded.PointsOfInterest;
using Stranded.ResourcesSystem;
using Stranded.Stats;

public abstract class AIReplenishNeedState<T> : AIState<T>
        where T : AIController
{
    protected abstract CharacterNeedType CharacterNeedType { get; }
    protected abstract StatType StatType { get; }

    private PointOfInterest pointOfInterest;
    private ResourceController resourceController;

    protected override bool ActionStartRequirementsFullfilled()
    {
        CharacterNeed characterNeed = Owner.CharacterNeedController.GetNeed(CharacterNeedType);

        if (characterNeed == null)
        {
            return false;
        }

        return Owner.CharacterNeedController.IsNeedBasedPOIInRange(CharacterNeedType, out pointOfInterest);
    }

    protected override bool ActionFinishRequirementsFulfilledIfDurationIsIgnored()
    {
        throw new System.NotImplementedException();
    }

    protected override void OnActionStarted()
    {
        // Make sure the character is rotated upside, so it can face it's target if needed
        Owner.AIRotation.RotateUpside(1f);

        resourceController = pointOfInterest.GetComponent<ResourceController>();
        resourceController?.StartInteracting(Owner.transform);
    }

    protected override void OnActionFinished()
    {
        if (resourceController == null)
        {
            return;
        }

        int resourceStrength = resourceController.Deplete(1, Owner.transform);
        Owner.StatsController.GetStat(StatType).Increment(resourceStrength);

        resourceController?.StopInteracting(Owner.transform);
        resourceController = null;
    }
}
