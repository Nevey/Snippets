using Stranded.Characters.Actions;
using Stranded.Characters.Needs;
using Stranded.Stats;

namespace Stranded.Characters.AI.StateMachines
{
    public class AIFeedState<T> : AIReplenishNeedState<T>
        where T : AIController
    {
        // TODO: Connect the below 3 enums somehow
        protected override CharacterActionType CharacterActionType => CharacterActionType.Feed;
        protected override CharacterNeedType CharacterNeedType => CharacterNeedType.Food;
        protected override StatType StatType => StatType.Fed;
    }
}
