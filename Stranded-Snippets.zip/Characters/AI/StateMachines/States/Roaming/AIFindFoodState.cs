﻿using Stranded.Characters.Actions;
using Stranded.Characters.Needs;

namespace Stranded.Characters.AI.StateMachines
{
    public class AIFindFoodState<T> : AIFindNeedSpotState<T>
        where T : AIController
    {
        // TODO: Connect the need and the action to each other
        protected override CharacterNeedType CharacterNeedType => CharacterNeedType.Food;
        protected override CharacterActionType LeaderActionType => CharacterActionType.Feed;
    }
}
