﻿using Stranded.Characters.Actions;
using Stranded.Characters.Needs;
using Stranded.Stats;

namespace Stranded.Characters.AI.StateMachines
{
    public class AISleepState<T> : AIReplenishNeedState<T>
        where T : AIController
    {
        protected override CharacterActionType CharacterActionType => CharacterActionType.Sleep;
        protected override CharacterNeedType CharacterNeedType => CharacterNeedType.Sleep;
        protected override StatType StatType => StatType.Stamina;
    }
}
