using Stranded.Characters.Actions;
using UnityEngine;

namespace Stranded.Characters.AI.StateMachines
{
    public class AIGetInRangeForAttackState<T> : AIState<T>
            where T : AIController
    {
        protected override CharacterActionType CharacterActionType => CharacterActionType.Travel;

        protected override bool ActionStartRequirementsFullfilled()
        {
            // I'm not targeting anything, so let's chillax a little bit
            if (Owner.AITargeting.SelectedTarget == null)
            {
                // Will stop the combat state machine...
                Owner.StopCombat();
                return false;
            }

            // I'm already in range, no need to try to get in range...
            if (GetDistanceToTarget() < Owner.AITargeting.TargetingRadius)
            {
                return false;
            }

            // I have a target, and I'm out of range to do an attack!
            return true;
        }

        protected override bool ActionFinishRequirementsFulfilledIfDurationIsIgnored()
        {
            if (Owner.AITargeting.SelectedTarget == null)
            {
                // Will stop the combat state machine...
                Owner.StopCombat();
                return false;
            }

            return GetDistanceToTarget() < Owner.AITargeting.TargetingRadius;
        }

        protected override void OnActionStarted()
        {
            Owner.AIMovement.StartMovingToTarget();
        }

        protected override void OnActionFinished()
        {
        }

        private float GetDistanceToTarget()
        {
            return Vector3.Distance(Owner.transform.position, Owner.AITargeting.SelectedTarget.transform.position);
        }
    }
}
