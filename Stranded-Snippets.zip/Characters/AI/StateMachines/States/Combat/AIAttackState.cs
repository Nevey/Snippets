using Stranded.Characters.Actions;

namespace Stranded.Characters.AI.StateMachines
{
    public class AIAttackState<T> : AIState<T>
            where T : AIController
    {
        protected override CharacterActionType CharacterActionType => CharacterActionType.Attack;

        protected override bool ActionStartRequirementsFullfilled()
        {
            return Owner.AITargeting.SelectedTarget != null;
        }

        protected override bool ActionFinishRequirementsFulfilledIfDurationIsIgnored()
        {
            throw new System.NotImplementedException();
        }

        protected override void OnActionStarted()
        {
            Owner.AISimpleAttack.AttackTarget();
        }

        protected override void OnActionFinished()
        {

        }
    }
}
