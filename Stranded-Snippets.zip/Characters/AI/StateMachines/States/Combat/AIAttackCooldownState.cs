using Stranded.Characters.Actions;
using Stranded.Characters.AI;
using Stranded.Characters.AI.StateMachines;

public class AIAttackCooldownState<T> : AIState<T>
            where T : AIController
{
    protected override CharacterActionType CharacterActionType => CharacterActionType.AttackCooldown;

    protected override bool ActionStartRequirementsFullfilled()
    {
        return true;
    }

    protected override bool ActionFinishRequirementsFulfilledIfDurationIsIgnored()
    {
        throw new System.NotImplementedException();
    }

    protected override void OnActionStarted()
    {
        Owner.AIRotation.PauseApplyRotation();
    }

    protected override void OnActionFinished()
    {
        Owner.AIRotation.ResumeApplyRotation();
    }
}
