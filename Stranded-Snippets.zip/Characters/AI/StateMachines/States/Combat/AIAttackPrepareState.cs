using Stranded.Characters.Actions;
using Stranded.Characters.AI;
using Stranded.Characters.AI.StateMachines;

public class AIAttackPrepareState<T> : AIState<T>
            where T : AIController
{
    protected override CharacterActionType CharacterActionType => CharacterActionType.AttackPrepare;

    protected override bool ActionStartRequirementsFullfilled()
    {
        return Owner.AITargeting.SelectedTarget != null;
    }

    protected override bool ActionFinishRequirementsFulfilledIfDurationIsIgnored()
    {
        throw new System.NotImplementedException();
    }

    protected override void OnActionStarted()
    {
        Owner.AIRotation.RotateUpside(ActionDuration);
    }

    protected override void OnActionFinished()
    {

    }
}
