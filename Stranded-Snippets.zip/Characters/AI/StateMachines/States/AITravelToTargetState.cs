using Stranded.Characters.Actions;
using Stranded.Characters.AI;
using Stranded.Characters.AI.StateMachines;

public class AITravelToTargetState<T> : AIState<T>
    where T : AIController
{
    protected override CharacterActionType CharacterActionType => CharacterActionType.Travel;

    protected override bool ActionStartRequirementsFullfilled()
    {
        return Owner.AITargeting.SelectedTarget != null;
    }

    protected override bool ActionFinishRequirementsFulfilledIfDurationIsIgnored()
    {
        return Owner.AISurroundingsAwareness.IsPointInAwarenessRange(Owner.AITargeting.TargetPosition);
    }

    protected override void OnActionStarted()
    {
        Owner.AIMovement.StartMovingToTarget();
    }

    protected override void OnActionFinished()
    {
        Owner.AIMovement.StopMovement();
    }
}
