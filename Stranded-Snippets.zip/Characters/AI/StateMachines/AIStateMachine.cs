using CardboardCore.StateMachines;

namespace Stranded.Characters.AI.StateMachines
{
    public class AIStateMachine<T> : StateMachine
        where T : AIController
    {
        private readonly T owner;

        public AIStateMachine(T owner, bool enableDebugging) : base(enableDebugging)
        {
            this.owner = owner;
        }

        protected void SetOwnerForAllStates()
        {
            foreach (var item in stateDict)
            {
                AIState<T> state = (AIState<T>)item.Value;
                state.SetOwner(owner);
            }
        }

        public void Update(float deltaTime)
        {
            if (currentState == null)
            {
                return;
            }

            AIState<T> aiState = (AIState<T>)currentState;
            aiState.Update(deltaTime);
        }
    }
}
