namespace Stranded.Characters.AI.StateMachines
{
    public class AIRoamingFollowerStateMachine<T> : AIStateMachine<T>
        where T : AIController
    {
        public AIRoamingFollowerStateMachine(T owner, bool enableDebugging) : base(owner, enableDebugging)
        {
            // The below order is important, find something, then see if we need to do something about it, etc.

            SetInitialState<AIIdleState<T>>();
            AddTransition<AIIdleState<T>, AIFindLeaderState<T>>();
            AddTransition<AIFindLeaderState<T>, AIFindFoodState<T>>();
            AddTransition<AIFindFoodState<T>, AIFeedState<T>>();
            AddTransition<AIFeedState<T>, AIFindSleepSpotState<T>>();
            AddTransition<AIFindSleepSpotState<T>, AISleepState<T>>();
            AddTransition<AISleepState<T>, AIFindRelaxSpotState<T>>();
            AddTransition<AIFindRelaxSpotState<T>, AIRelaxState<T>>();
            AddTransition<AIRelaxState<T>, AITravelToTargetState<T>>();
            AddTransition<AITravelToTargetState<T>, AIIdleState<T>>();

            SetOwnerForAllStates();
        }
    }
}
