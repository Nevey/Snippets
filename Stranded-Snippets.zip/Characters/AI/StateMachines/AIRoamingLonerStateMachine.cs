namespace Stranded.Characters.AI.StateMachines
{
    public class AIRoamingLonerStateMachine<T> : AIStateMachine<T>
        where T : AIController
    {
        public AIRoamingLonerStateMachine(T owner, bool enableDebugging) : base(owner, enableDebugging)
        {
        }
    }
}
