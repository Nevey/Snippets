using System.Collections.Generic;
using CardboardCore.DI;

namespace Stranded.Characters.AI
{
    [Injectable(Singleton = true)]
    public class AIRegistry
    {
        private readonly Dictionary<CharacteristicsType, List<AIController>> aiDict =
            new Dictionary<CharacteristicsType, List<AIController>>();

        private List<AIController> GetAIOfCharacterType(CharacteristicsType characteristicsType)
        {
            if (!aiDict.ContainsKey(characteristicsType))
            {
                Log.Warn($"No {characteristicsType} found!");
                return new List<AIController>();
            }

            return aiDict[characteristicsType];
        }

        public void RegisterAI(AIController aiController)
        {
            if (!aiDict.ContainsKey(aiController.AICharacteristics.CharacteristicsType))
            {
                aiDict[aiController.AICharacteristics.CharacteristicsType] = new List<AIController>();
            }

            if (aiDict[aiController.AICharacteristics.CharacteristicsType].Contains(aiController))
            {
                return;
            }

            aiDict[aiController.AICharacteristics.CharacteristicsType].Add(aiController);
        }

        public void UnregisterAI(AIController aiController)
        {
            if (!aiDict.ContainsKey(aiController.AICharacteristics.CharacteristicsType))
            {
                return;
            }

            if (!aiDict[aiController.AICharacteristics.CharacteristicsType].Contains(aiController))
            {
                return;
            }

            aiDict[aiController.AICharacteristics.CharacteristicsType].Remove(aiController);
        }

        public List<AIController> GetLeaders()
        {
            return GetAIOfCharacterType(CharacteristicsType.Leader);
        }

        public List<AIController> GetFollowers()
        {
            return GetAIOfCharacterType(CharacteristicsType.Follower);
        }

        public List<AIController> GetLoners()
        {
            return GetAIOfCharacterType(CharacteristicsType.Loner);
        }
    }
}
