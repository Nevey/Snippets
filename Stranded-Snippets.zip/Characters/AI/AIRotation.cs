using Stranded.Characters.Rotation;
using UnityEngine;

namespace Stranded.Characters.AI
{
    [AddComponentMenu("Stranded/Characters/AI/AIRotation")]
    [RequireComponent(typeof(AITargeting))]
    public class AIRotation : CharacterRotation
    {
        [SerializeField] private bool applyRotation;

        private AITargeting aiTargeting;
        private bool isPaused;

        protected override void Awake()
        {
            base.Awake();
            aiTargeting = GetComponent<AITargeting>();
        }

        private void Update()
        {
            if (!applyRotation || isPaused)
            {
                return;
            }

            Vector3 direction = aiTargeting.TargetPosition - transform.position;

            if (direction == Vector3.zero)
            {
                return;
            }

            Vector3 euler = Quaternion.LookRotation(direction, Vector3.up).eulerAngles;
            euler.x = 0;

            SetTargetRotation(Quaternion.Euler(euler));
        }

        public void PauseApplyRotation()
        {
            isPaused = true;
        }

        public void ResumeApplyRotation()
        {
            isPaused = false;
        }
    }
}
