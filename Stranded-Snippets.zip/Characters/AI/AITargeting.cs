﻿using System.Collections.Generic;
using System.Linq;
using CardboardCore.DI;
using Stranded.Characters.Combat.Targeting;
using Stranded.PointsOfInterest;
using UnityEngine;
using UnityEngine.AI;

namespace Stranded.Characters.AI
{
    // TODO: This is now a bit of a hybrid class, remove the TargetPosition as used in this class and lean on TargetingController a bit more. POI stuff seems nice to keep around
    [AddComponentMenu("Stranded/Characters/AI/AITargeting")]
    public class AITargeting : TargetingController
    {
        [SerializeField] private Bounds movementBounds;
        [SerializeField] private bool debug;

        [Inject] private PointOfInterestManager pointOfInterestManager;

        private Transform target;
        private Vector3 sampledPosition;
        private bool samplePosition;

        // Facepalm...
        public Vector3 TargetPosition =>
            target == null ?
                transform.position :
                samplePosition ?
                    sampledPosition :
                    target.position;

        public Transform Target => target;

        private void OnDrawGizmos()
        {
            if (!debug)
            {
                return;
            }

            Gizmos.color = Color.green;
            Gizmos.DrawWireCube(movementBounds.center, movementBounds.size);
        }

        private PointOfInterest GetPointOfInterestWithinBounds(Bounds bounds, PointOfInterestType pointOfInterestType)
        {
            List<PointOfInterest> possiblePOIS = pointOfInterestManager.GetPOIS(pointOfInterestType);

            if (possiblePOIS == null)
            {
                return null;
            }

            possiblePOIS = possiblePOIS.Where(x => bounds.Contains(x.transform.position)).ToList();

            float distance = bounds.size.magnitude;
            PointOfInterest closestPOI = null;
            for (int i = 0; i < possiblePOIS.Count; i++)
            {
                PointOfInterest pointOfInterest = possiblePOIS[i];
                float d = Vector3.Distance(transform.position, pointOfInterest.transform.position);

                if (d < distance)
                {
                    closestPOI = pointOfInterest;
                    distance = d;
                }
            }

            return closestPOI;
        }

        private bool DetermineRandomTargetLocation(PointOfInterestType pointOfInterestType, bool samplePosition = false)
        {
            PointOfInterest POI = GetPointOfInterestWithinBounds(movementBounds, pointOfInterestType);

            if (POI == null)
            {
                UnselectCurrentTarget();
                SetTarget(null, samplePosition);
                return false;
            }

            SelectSpecificTarget(TargetableFlags.AI, POI);

            return SetTarget(POI.transform, samplePosition);
        }

        public bool SetClosestTargetLocation(PointOfInterestType pointOfInterestType)
        {
            return DetermineRandomTargetLocation(pointOfInterestType);
        }

        /// <summary>
        /// Note: when sampling position, it'll be a static point in the world
        /// </summary>
        /// <param name="target"></param>
        /// <param name="samplePosition"></param>
        public bool SetTarget(Transform target, bool samplePosition = false)
        {
            if (target != null)
            {
                AIFollowPoint[] aiFollowPoints = target.GetComponentsInChildren<AIFollowPoint>();

                if (aiFollowPoints.Length > 0)
                {
                    // TODO: Add random point in sphere for ai to follow, instead of one specific point
                    int randomIndex = Random.Range(0, aiFollowPoints.Length);
                    this.target = aiFollowPoints[randomIndex].transform;
                }
                else
                {
                    this.target = target;
                }
            }
            else
            {
                this.target = null;
            }

            this.samplePosition = samplePosition;

            if (samplePosition)
            {
                if (NavMesh.SamplePosition(target.position, out NavMeshHit hit, 500f, NavMesh.AllAreas))
                {
                    sampledPosition = hit.position;
                    return true;
                }

                return false;
            }

            return true;
        }

        public bool SetTarget(Targetable targetable)
        {
            if (!targetable.TargetableBy.HasFlag(TargetableFlags.AI))
            {
                return false;
            }

            SelectSpecificTarget(TargetableFlags.AI, targetable);
            SetTarget(targetable.transform);

            return true;
        }
    }
}
