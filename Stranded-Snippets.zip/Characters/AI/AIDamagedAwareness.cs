using System;
using Stranded.Characters.AI;
using Stranded.Characters.Combat.Attacking;
using Stranded.Characters.Combat.Targeting;
using UnityEngine;

// TODO: Create some kind of interruption controller and make this part of it
[RequireComponent(typeof(Damageable))]
[RequireComponent(typeof(AITargeting))]
public class AIDamagedAwareness : MonoBehaviour
{
    private Damageable damageable;
    private AITargeting aiTargeting;

    public event Action DamagedEvent;

    private void Awake()
    {
        damageable = GetComponent<Damageable>();
        damageable.HurtByTargetableEvent += OnHurtByTargetable;

        aiTargeting = GetComponent<AITargeting>();
    }

    private void OnDestroy()
    {
        damageable.HurtByTargetableEvent -= OnHurtByTargetable;
    }

    private void OnHurtByTargetable(Targetable targetableDoingDamageToMe)
    {
        Log.Write(targetableDoingDamageToMe.name);

        aiTargeting.SetTarget(targetableDoingDamageToMe);

        DamagedEvent?.Invoke();
    }
}
