﻿using System.Collections.Generic;
using CardboardCore.DI;
using Stranded.PointsOfInterest;
using UnityEngine;

namespace Stranded.Characters.AI
{
    public class AISurroundingsAwareness : CardboardCoreBehaviour
    {
        [SerializeField] private float defaultAwarenessRadius = 2.5f;
        [SerializeField] private float alertedAwarenessRadius = 3.5f;
        [SerializeField] private float relaxedAwarenessRadius = 1f;
        [SerializeField] private Color gizmoColor;

        [Inject] private AIRegistry aiRegistry;
        [Inject] private PointOfInterestManager pointOfInterestManager;

        private float currentAwarenessRadius;

        protected override void Start()
        {
            base.Start();
            SetDefaultAwareness();
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = gizmoColor;
            Gizmos.DrawSphere(transform.position, currentAwarenessRadius);
        }

        public void SetDefaultAwareness()
        {
            currentAwarenessRadius = defaultAwarenessRadius;
        }

        public void SetAlertedAwareness()
        {
            currentAwarenessRadius = alertedAwarenessRadius;
        }

        public void SetRelaxedAwareness()
        {
            currentAwarenessRadius = relaxedAwarenessRadius;
        }

        public bool IsObjectInAwarenessRange<T>(T item) where T : MonoBehaviour
        {
            float distance = Vector3.Distance(transform.position, item.transform.position);
            return distance < currentAwarenessRadius;
        }

        public bool IsObjectInAwarenessRange<T>(List<T> list, out T item) where T : MonoBehaviour
        {
            item = null;

            if (list == null)
            {
                return false;
            }

            float smallestDistance = currentAwarenessRadius;

            for (int i = 0; i < list.Count; i++)
            {
                float distance = Vector3.Distance(transform.position, list[i].transform.position);

                if (distance >= smallestDistance)
                {
                    continue;
                }

                if (list[i] is PointOfInterest pointOfInterest)
                {
                    if (pointOfInterest.IsNoLongerInteresting)
                    {
                        continue;
                    }
                }

                item = list[i];
                smallestDistance = distance;
            }

            return item != null;
        }

        public bool IsPOIInRange(PointOfInterestType pointOfInterestType, out PointOfInterest pointOfInterest)
        {
            List<PointOfInterest> POIList = pointOfInterestManager.GetPOIS(pointOfInterestType);
            return IsObjectInAwarenessRange(POIList, out pointOfInterest);
        }

        public bool IsLeaderInRange(out AIController aiController)
        {
            List<AIController> aiControllers = aiRegistry.GetLeaders();
            return IsObjectInAwarenessRange(aiControllers, out aiController);
        }

        public bool IsPointInAwarenessRange(Vector3 point)
        {
            float distance = Vector3.Distance(transform.position, point);
            return distance < currentAwarenessRadius;
        }
    }
}
