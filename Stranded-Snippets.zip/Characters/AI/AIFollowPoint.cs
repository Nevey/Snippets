﻿using UnityEngine;

namespace Stranded.Characters.AI
{
    public class AIFollowPoint : MonoBehaviour
    {
        
    }
}