using System;
using CardboardCore.DI;
using Stranded.Characters.Actions;
using Stranded.Characters.AI.StateMachines;
using Stranded.Characters.Combat.Targeting;
using Stranded.Characters.Needs;
using Stranded.Stats;
using UnityEditor;
using UnityEngine;

namespace Stranded.Characters.AI
{
    public enum CharacteristicsType
    {
        Leader,
        Loner,
        Follower
    }

    [Serializable]
    public class AICharacteristics
    {
        [SerializeField] private CharacteristicsType characteristicsType;

        public CharacteristicsType CharacteristicsType => characteristicsType;
    }

    [RequireComponent(typeof(AITargeting))]
    [RequireComponent(typeof(AIMovement))]
    [RequireComponent(typeof(AIRotation))]
    [RequireComponent(typeof(AISurroundingsAwareness))]
    [RequireComponent(typeof(CharacterActionController))]
    [RequireComponent(typeof(CharacterNeedController))]
    [RequireComponent(typeof(StatsController))]
    public class AIController : CardboardCoreBehaviour
    {
        [SerializeField] private AICharacteristics aiCharacteristics;
        [SerializeField] private bool debugStateMachines;

        [Inject] private AIRegistry aiRegistry;

        private AIStateMachine<AIController> roamingStateMachine;
        private AICombatStateMachine<AIController> combatStateMachine;
        private AIController leaderToFollow;

        public AICharacteristics AICharacteristics => aiCharacteristics;
        public AIController LeaderToFollow => leaderToFollow;

        public AITargeting AITargeting { get; private set; }
        public AIMovement AIMovement { get; private set; }
        public AIRotation AIRotation { get; private set; }
        public AIDamagedAwareness AIDamagedAwareness { get; private set; }
        public AISurroundingsAwareness AISurroundingsAwareness { get; private set; }
        public CharacterActionController CharacterActionController { get; private set; }
        public CharacterNeedController CharacterNeedController { get; private set; }
        public StatsController StatsController { get; private set; }
        public AISimpleAttack AISimpleAttack { get; private set; }
        public Targetable AITargetable { get; private set; }

        protected override void Awake()
        {
            base.Awake();

            aiRegistry.RegisterAI(this);

            AITargeting = GetComponent<AITargeting>();
            AIMovement = GetComponent<AIMovement>();
            AIRotation = GetComponent<AIRotation>();
            AIDamagedAwareness = GetComponent<AIDamagedAwareness>();
            AISurroundingsAwareness = GetComponent<AISurroundingsAwareness>();
            CharacterActionController = GetComponent<CharacterActionController>();
            CharacterNeedController = GetComponent<CharacterNeedController>();
            StatsController = GetComponent<StatsController>();

            // Might be null
            AISimpleAttack = GetComponent<AISimpleAttack>();
            AITargetable = GetComponent<Targetable>();
        }

        protected override void Start()
        {
            base.Start();

            StartDefaultStateMachine();
        }

        protected override void OnDestroy()
        {
            AIDamagedAwareness.DamagedEvent -= OnDamagedEvent;

            aiRegistry.UnregisterAI(this);

            roamingStateMachine?.Stop();
            combatStateMachine?.Stop();

            base.OnDestroy();
        }

        private void Update()
        {
            roamingStateMachine?.Update(Time.deltaTime);
        }

        private void FixedUpdate()
        {
            combatStateMachine?.Update(Time.fixedDeltaTime);
        }

        private void OnDrawGizmos()
        {
            if (roamingStateMachine == null)
            {
                return;
            }

            Vector3 position = transform.position;
            position.y += 2f;
            Handles.Label(position, $"State: {roamingStateMachine.CurrentState.GetType().Name}");
        }

        private void StartDefaultStateMachine()
        {
            switch (aiCharacteristics.CharacteristicsType)
            {
                case CharacteristicsType.Leader:
                    roamingStateMachine = new AIRoamingLeaderStateMachine<AIController>(this, debugStateMachines);
                    break;

                case CharacteristicsType.Follower:
                    roamingStateMachine = new AIRoamingFollowerStateMachine<AIController>(this, debugStateMachines);
                    break;

                case CharacteristicsType.Loner:
                    roamingStateMachine = new AIRoamingLonerStateMachine<AIController>(this, debugStateMachines);
                    break;
            }

            roamingStateMachine.Start();

            AIDamagedAwareness.DamagedEvent += OnDamagedEvent;
        }

        private void OnDamagedEvent()
        {
            // If already in combat, don't interrupt our current flow
            if (AISimpleAttack.InCombat)
            {
                return;
            }

            StopRoaming();

            combatStateMachine = new AICombatStateMachine<AIController>(this, debugStateMachines);
            combatStateMachine.Start();
        }

        public void SetLeaderToFollow(AIController aiController)
        {
            leaderToFollow = aiController;
        }

        public void StopAll()
        {
            StopRoaming();
            StopCombat();

            AIMovement.Stop();
        }

        public void StopRoaming()
        {
            AIDamagedAwareness.DamagedEvent -= OnDamagedEvent;

            CharacterActionController.CancelAction(false);
            AIMovement.StopMovement();

            roamingStateMachine.Stop();
            roamingStateMachine = null;
        }

        public void StopCombat()
        {
            combatStateMachine?.Stop();
            combatStateMachine = null;

            StartDefaultStateMachine();
        }
    }
}
