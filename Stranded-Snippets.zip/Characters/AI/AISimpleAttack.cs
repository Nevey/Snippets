using System;
using Stranded.Characters.Combat.Attacking;
using UnityEngine;

namespace Stranded.Characters.AI
{
    [RequireComponent(typeof(AIMovement))]
    [RequireComponent(typeof(AIController))]
    [RequireComponent(typeof(AITargeting))]
    public class AISimpleAttack : AttackController
    {
        private enum AttackType
        {
            Dash,
            Jump
        }

        [Header("AI Simple Attack Settings")]
        [SerializeField, Tooltip("The movement speed of the attack")] private float attackSpeed;
        [SerializeField, Tooltip("The duration of the attack")] private float attackDuration;
        [SerializeField] private AttackType attackType;

        private AIController aiController;
        private AIMovement aiMovement;
        private AITargeting aiTargeting;

        private AttackHandler attackHandler;
        private bool inCombat;
        private Action attackFinishedCallback;

        public bool InCombat => inCombat;

        private void Awake()
        {
            aiController = GetComponent<AIController>();
            aiMovement = GetComponent<AIMovement>();
            aiTargeting = GetComponent<AITargeting>();
        }

        private void OnDestroy()
        {
            if (attackHandler != null)
            {
                attackHandler.AttackFinishedEvent -= OnAttackFinished;
            }
        }

        private void Update()
        {
            if (!inCombat || attackHandler == null)
            {
                return;
            }

            attackHandler.UpdateAttack(Time.deltaTime);
        }

        private void OnAttackFinished()
        {
            attackHandler.AttackFinishedEvent -= OnAttackFinished;
            attackHandler = null;

            inCombat = false;

            // Copy action to support chaining
            Action callback = attackFinishedCallback;
            attackFinishedCallback = null;

            callback?.Invoke();
        }

        public void AttackTarget(Action callback = null)
        {
            if (aiTargeting.SelectedTarget == null)
            {
                return;
            }

            inCombat = true;
            attackFinishedCallback = callback;

            PrepareNewAttack();

            switch (attackType)
            {
                case AttackType.Dash:

                    DashAttackHandlerData dashAttackHandlerData = new DashAttackHandlerData(
                        aiTargeting.SelectedTarget, attackArea, attackSpeed, attackDuration, transform);

                    DashAttackHandler dashAttackHandler = new DashAttackHandler();
                    dashAttackHandler.StartAttack(dashAttackHandlerData, DoAttack);

                    attackHandler = dashAttackHandler;

                    break;

                case AttackType.Jump:
                    break;

                default:
                    throw Log.Exception($"AttackType {attackType} was not implemented!");
            }

            attackHandler.AttackFinishedEvent += OnAttackFinished;
        }
    }
}
